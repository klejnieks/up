'use strict';
var ErrorModel = require('../model/ErrorModel');
var Watchlist = require('../model/Watchlist');
var Endpoints = require('../model/Endpoints');
var Environments = require('../model/Environments');
var Settings = require('../model/Settings');

/**
* WatchlistService service.
* @module api/WatchlistServiceApi
* @version 1.0.1
*/

/**
* Constructs a new WatchlistServiceApi. 
* @alias module:api/WatchlistServiceApi
* @class
* @param {module:ApiClient} apiClient Optional API client implementation to use,
* default to {@link module:ApiClient#instance} if unspecified.
*/
class WatchlistServiceApi {


    
    /**
    * Returns the account blotter for a given user and account id
    * @param {String} userId ID of user to fetch
    * data is of type: {module:model/Watchlist}
    */
    get(userId) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/users/" + userId + "/settings/watchList", {
    			method: 'GET',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'x-mysolomeo-session-key': User.sessionKey
                    }
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns the account blotter for a given user and account id
    * @param {String} userId set of parameters to get chart data. ***NEEDS WORK***
    * @param {Object} opts Optional parameters
    * @param {Object} data username for forgot password
    * data is of type: {module:model/Watchlist}
    */
    save(userId, data) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/users/" + userId + "/settings", {
    			method: 'POST',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'x-mysolomeo-session-key': User.sessionKey
                    },
                    body: JSON.stringify(data)
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

};

module.exports = new WatchlistServiceApi();

