'use strict';
var ErrorModel = require('../model/ErrorModel');
var Blotter = require('../model/Blotter');
var Instrument = require('../model/Instrument');
var Instruments = require('../model/Instruments');
var Endpoints = require('../model/Endpoints');
var Environments = require('../model/Environments');
var Settings = require('../model/Settings');

/**
* InstrumentService service.
* @module api/InstrumentServiceApi
* @version 1.0.1
*/

/**
* Constructs a new InstrumentServiceApi. 
* @alias module:api/InstrumentServiceApi
* @class
* @param {module:ApiClient} apiClient Optional API client implementation to use,
* default to {@link module:ApiClient#instance} if unspecified.
*/
class InstrumentServiceApi {


    
    /**
    * Returns the account blotter for a given user and account id
    * @param {String} params set of parameters to get chart data. ***NEEDS WORK***
    * data is of type: {module:model/Blotter}
    */
    getBarsData(params) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/bars?instrumentID=" + params + "", {
    			method: 'GET',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'x-mysolomeo-session-key': User.sessionKey
                    }
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns details on a specific instrument.
    * @param {String} instrumentID ID of Instrument to fetch
    * data is of type: {module:model/Instrument}
    */
    getInstrumentByID(instrumentID) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/instruments/" + instrumentID + "?options=F", {
    			method: 'GET',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'x-mysolomeo-session-key': User.sessionKey
                    }
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns the account blotter for a given user and account id
    * @param {String} symbols Array of symbols of Instrument to fetch
    * data is of type: {module:model/Instruments}
    */
    getInstrumentBySymbols(symbols) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/instruments/?symbols=" + symbols + "", {
    			method: 'GET',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'x-mysolomeo-session-key': User.sessionKey
                    }
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns the account blotter for a given user and account id
    * @param {String} params ID of user to fetch
    * data is of type: {module:model/Instruments}
    */
    getInstruments(params) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/instruments?" + params + "", {
    			method: 'GET',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'x-mysolomeo-session-key': User.sessionKey
                    }
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

};

module.exports = new InstrumentServiceApi();

