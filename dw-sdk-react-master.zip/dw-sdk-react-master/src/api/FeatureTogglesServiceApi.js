'use strict';
var FeatureToggles = require('../model/FeatureToggles');
var ErrorModel = require('../model/ErrorModel');
var Endpoints = require('../model/Endpoints');
var Environments = require('../model/Environments');
var Settings = require('../model/Settings');

/**
* FeatureTogglesService service.
* @module api/FeatureTogglesServiceApi
* @version 1.0.1
*/

/**
* Constructs a new FeatureTogglesServiceApi. 
* @alias module:api/FeatureTogglesServiceApi
* @class
* @param {module:ApiClient} apiClient Optional API client implementation to use,
* default to {@link module:ApiClient#instance} if unspecified.
*/
class FeatureTogglesServiceApi {


    
    /**
    * Returns the account blotter for a given user and account id
    * data is of type: {module:model/FeatureToggles}
    */
    getFeatureToggles() {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/featureToggles", {
    			method: 'GET',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'x-mysolomeo-session-key': User.sessionKey
                    }
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

};

module.exports = new FeatureTogglesServiceApi();

