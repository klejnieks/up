'use strict';
var ErrorModel = require('../model/ErrorModel');
var User = require('../model/User');
var Blotter = require('../model/Blotter');
var Endpoints = require('../model/Endpoints');
var Environments = require('../model/Environments');
var Settings = require('../model/Settings');

/**
* UserService service.
* @module api/UserServiceApi
* @version 1.0.1
*/

/**
* Constructs a new UserServiceApi. 
* @alias module:api/UserServiceApi
* @class
* @param {module:ApiClient} apiClient Optional API client implementation to use,
* default to {@link module:ApiClient#instance} if unspecified.
*/
class UserServiceApi {


    
    /**
    * Returns the account blotter for a given user and account id
    * @param {String} userID ID of user to fetch
    * @param {Object} opts Optional parameters
    * @param {Object} data username for forgot password
    */
    edit(userID, data) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/users/" + userID + "", {
    			method: 'PUT',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns a user based on a single ID
    * @param {String} userID ID of user to fetch
    * @param {Object} opts Optional parameters
    * @param {Object} data username for forgot password
    * data is of type: {module:model/User}
    */
    forgotPassword(userID, data) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/users/passwords" + username + "", {
    			method: 'POST',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns the account blotter for a given user and account id
    * @param {String} userID ID of user to fetch
    * @param {String} key ID of user to fetch
    * data is of type: {module:model/Blotter}
    */
    getSetting(userID, key) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/users/" + userID + "/settings/" + key + "", {
    			method: 'GET',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'x-mysolomeo-session-key': User.sessionKey
                    }
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns the account blotter for a given user and account id
    * @param {String} userID ID of user to fetch
    * data is of type: {module:model/User}
    */
    getStatus(userID) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/users/" + userID + "/status", {
    			method: 'GET',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'x-mysolomeo-session-key': User.sessionKey
                    }
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns a user based on a single ID
    * @param {String} sessionKey session key of the user
    * data is of type: {module:model/User}
    */
    getUser(sessionKey) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/userSessions/" + sessionKey + "", {
    			method: 'GET',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'x-mysolomeo-session-key': User.sessionKey
                    }
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns a user based on a single ID
    * @param {String} id ID of user to fetch
    * data is of type: {module:model/User}
    */
    getUserByUserID(id) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/users/" + id + "", {
    			method: 'GET',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'x-mysolomeo-session-key': User.sessionKey
                    }
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns the account blotter for a given user and account id
    * @param {String} sessionKey ID of user to fetch
    */
    heartbeat(sessionKey) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/userSessions/" + sessionKey + "?action=heartbeat", {
    			method: 'PUT',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    }
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns the account blotter for a given user and account id
    * @param {String} username ID of user to fetch
    * data is of type: {module:model/User}
    */
    isUsernameAvailable(username) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/users?username=" + username + "", {
    			method: 'GET',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    }
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * User Login
    * @param {Object} opts Optional parameters
    * @param {Object} data username for forgot password
    * data is of type: {module:model/User}
    */
    login(data) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/userSessions", {
    			method: 'POST',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns a user based on a single ID
    * @param {String} code username for forgot password
    * @param {Object} data username for forgot password
    * data is of type: {module:model/User}
    */
    resetPassword(code, data) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/users/passwords/" + code + "", {
    			method: 'PUT',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns a user based on a single ID
    * @param {String} userID ID of user to fetch
    * @param {Object} opts Optional parameters
    * @param {Object} data username for forgot password
    * data is of type: {module:model/User}
    */
    saveSetting(userID, data) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/users/" + userID + "/settings", {
    			method: 'POST',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns a user based on a single ID
    * @param {String} passwordResetID username for forgot password
    * @param {Object} opts Optional parameters
    * @param {Object} data username for forgot password
    * data is of type: {module:model/User}
    */
    setPassword(passwordResetID, data) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/users/passwords/" + passwordResetID + "", {
    			method: 'POST',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns a user based on a single ID
    * @param {Object} opts Optional parameters
    * @param {Object} data User signup data object
    * data is of type: {module:model/User}
    */
    signupLive(data) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/signups/live", {
    			method: 'POST',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns a user based on a single ID
    * @param {Object} opts Optional parameters
    * @param {Object} data username for forgot password
    * data is of type: {module:model/User}
    */
    signupPractice(data) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/signups/practice", {
    			method: 'POST',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

};

module.exports = new UserServiceApi();

