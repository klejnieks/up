'use strict';
var ErrorModel = require('../model/ErrorModel');
var Blotter = require('../model/Blotter');
var Endpoints = require('../model/Endpoints');
var Environments = require('../model/Environments');
var Settings = require('../model/Settings');

/**
* OrderService service.
* @module api/OrderServiceApi
* @version 1.0.1
*/

/**
* Constructs a new OrderServiceApi. 
* @alias module:api/OrderServiceApi
* @class
* @param {module:ApiClient} apiClient Optional API client implementation to use,
* default to {@link module:ApiClient#instance} if unspecified.
*/
class OrderServiceApi {


    
    /**
    * Returns the account blotter for a given user and account id
    * @param {String} orderID set of parameters to get chart data. ***NEEDS WORK***
    * data is of type: {module:model/Blotter}
    */
    cancel(orderID) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/orders/" + orderID + "", {
    			method: 'DELETE',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'x-mysolomeo-session-key': User.sessionKey
                    }
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    
    /**
    * Returns the account blotter for a given user and account id
    * @param {Object} opts Optional parameters
    * @param {Object} data username for forgot password
    * data is of type: {module:model/Blotter}
    */
    submitBasketOrders(data) {
        return new Promise((resolve, reject) => {
            fetch(Endpoints.api[Settings.serviceHost] + "/orders", {
    			method: 'POST',
    			headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'x-mysolomeo-session-key': User.sessionKey
                    },
                    body: JSON.stringify(data)
        	})
            .then(response => {
                if(response.ok) {
                    resolve(response.json());
                }
                else {
                    reject(response.text());
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

};

module.exports = new OrderServiceApi();

