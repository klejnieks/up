'use strict';

/**
  * DriveWealth SDK for client application implementation.<br>
  * The <code>index</code> module provides access to constructors for all the classes which comprise the public API.
  * <p>
  * An AMD (recommended!) or CommonJS application will generally do something equivalent to the following:
  * <pre>
  * var DrivewealthSdk = require('index'); // See note below*.
  * var xxxSvc = new DrivewealthSdk.XxxApi(); // Allocate the API class we're going to use.
  * var yyyModel = new DrivewealthSdk.Yyy(); // Construct a model instance.
  * yyyModel.someProperty = 'someValue';
  * ...
  * var zzz = xxxSvc.doSomething(yyyModel); // Invoke the service.
  * ...
  * </pre>
  * <em>*NOTE: For a top-level AMD script, use require(['index'], function(){...})
  * and put the application logic within the callback function.</em>
  * </p>
  * <p>
  * A non-AMD browser application (discouraged) might do something like this:
  * <pre>
  * var xxxSvc = new DrivewealthSdk.XxxApi(); // Allocate the API class we're going to use.
  * var yyy = new DrivewealthSdk.Yyy(); // Construct a model instance.
  * yyyModel.someProperty = 'someValue';
  * ...
  * var zzz = xxxSvc.doSomething(yyyModel); // Invoke the service.
  * ...
  * </pre>
  * </p>
  * @module index
  * @version 1.0.1
  **/
    var Account = require('./model/Account');
    var Blotter = require('./model/Blotter');
    var Cash = require('./model/Cash');
    var Endpoints = require('./model/Endpoints');
    var Environments = require('./model/Environments');
    var Equity = require('./model/Equity');
    var ErrorModel = require('./model/ErrorModel');
    var FeatureToggle = require('./model/FeatureToggle');
    var FeatureToggles = require('./model/FeatureToggles');
    var Fundamental = require('./model/Fundamental');
    var Instrument = require('./model/Instrument');
    var Instruments = require('./model/Instruments');
    var Orders = require('./model/Orders');
    var Positions = require('./model/Positions');
    var Settings = require('./model/Settings');
    var Transactions = require('./model/Transactions');
    var User = require('./model/User');
    var Watchlist = require('./model/Watchlist');

    
    var AccountsServiceApi = require('./api/AccountsServiceApi');
    
    var FeatureTogglesServiceApi = require('./api/FeatureTogglesServiceApi');
    
    var InstrumentServiceApi = require('./api/InstrumentServiceApi');
    
    var OrderServiceApi = require('./api/OrderServiceApi');
    
    var UserServiceApi = require('./api/UserServiceApi');
    
    var WatchlistServiceApi = require('./api/WatchlistServiceApi');
    

    var EventManager = require('./utils/EventManager');
    var Events = require('./events/Events');
    var Watch = require('watchjs');

    var DrivewealthSdk = {
        Account: Account,
        Blotter: Blotter,
        Cash: Cash,
        Endpoints: Endpoints,
        Environments: Environments,
        Equity: Equity,
        ErrorModel: ErrorModel,
        FeatureToggle: FeatureToggle,
        FeatureToggles: FeatureToggles,
        Fundamental: Fundamental,
        Instrument: Instrument,
        Instruments: Instruments,
        Orders: Orders,
        Positions: Positions,
        Settings: Settings,
        Transactions: Transactions,
        User: User,
        Watchlist: Watchlist,

        
        AccountsServiceApi: AccountsServiceApi,
        
        FeatureTogglesServiceApi: FeatureTogglesServiceApi,
        
        InstrumentServiceApi: InstrumentServiceApi,
        
        OrderServiceApi: OrderServiceApi,
        
        UserServiceApi: UserServiceApi,
        
        WatchlistServiceApi: WatchlistServiceApi,
        

        EventManager: EventManager,
        Events: Events,
        Watch: Watch,
    }

    module.exports = DrivewealthSdk;
