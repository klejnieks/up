'use strict';





/**
* The Orders model module.
* @module model/Orders
* @version 1.0.1
**/

/**
* Constructs a new <code>Orders</code>.
* @alias module:model/Orders
* @class
*/


class Orders {

    constructor(value) {
        this.orderID = value.orderID;
        this.orderNo = value.orderNo;
        this.createdWhen = value.createdWhen;
        this.symbol = value.symbol;
        this.cumQty = value.cumQty;
        this.orderStatus = value.orderStatus;
        this.orderType = value.orderType;
        this.orderQty = value.orderQty;
        this.limitPrice = value.limitPrice;
        this.side = value.side;
        this.orderCashAmt = value.orderCashAmt;
        this.stopPrice = value.stopPrice;
    }


    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        this.orderID = null;
        this.orderNo = null;
        this.createdWhen = null;
        this.symbol = null;
        this.cumQty = null;
        this.orderStatus = null;
        this.orderType = null;
        this.orderQty = null;
        this.limitPrice = null;
        this.side = null;
        this.orderCashAmt = null;
        this.stopPrice = null;
        
        
    }

    toString() {
        return JSON.stringify({
            baseName: this.orderID,
            baseName: this.orderNo,
            baseName: this.createdWhen,
            baseName: this.symbol,
            baseName: this.cumQty,
            baseName: this.orderStatus,
            baseName: this.orderType,
            baseName: this.orderQty,
            baseName: this.limitPrice,
            baseName: this.side,
            baseName: this.orderCashAmt,
            baseName: this.stopPrice
            
            
        });
    }

};
module.exports = Orders;




