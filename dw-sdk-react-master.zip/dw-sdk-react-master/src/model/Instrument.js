'use strict';




var Fundamental = require('./Fundamental');

/**
* The Instrument model module.
* @module model/Instrument
* @version 1.0.1
**/

/**
* Constructs a new <code>Instrument</code>.
* @alias module:model/Instrument
* @class
*/


class Instrument {

    constructor(value) {
        this.instrumentID = value.instrumentID;
        this.name3 = value.name3;
        this.name = value.name;
        this.currencyID = value.currencyID;
        this.description = value.description;
        this.exchangeID = value.exchangeID;
        this.limitStatus = value.limitStatus;
        this.instrumentTypeID = value.instrumentTypeID;
        this.isLongOnly = value.isLongOnly;
        this.marginCurrencyID = value.marginCurrencyID;
        this.orderSizeMax = value.orderSizeMax;
        this.orderSizeMin = value.orderSizeMin;
        this.orderSizeStep = value.orderSizeStep;
        this.rateAsk = value.rateAsk;
        this.rateBid = value.rateBid;
        this.ratePrecision = value.ratePrecision;
        this.symbol = value.symbol;
        this.tradeStatus = value.tradeStatus;
        this.tradingHours = value.tradingHours;
        this.uom = value.uom;
        this.urlImage = value.urlImage;
        this.urlInvestor = value.urlInvestor;
        this.sector = value.sector;
        this.priorClose = value.priorClose;
        this.nameLower = value.nameLower;
        this.underlyingID = value.underlyingID;
        this.marketState = value.marketState;
        this.minTic = value.minTic;
        this.pipMultiplier = value.pipMultiplier;
        this.tickerSymbol = value.tickerSymbol;
        this.rebateSpread = value.rebateSpread;
        this.longOnly = value.longOnly;
        this.fundamentalDataModel = value.fundamentalDataModel;
    }


    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        this.instrumentID = null;
        this.name3 = null;
        this.name = null;
        this.currencyID = null;
        this.description = null;
        this.exchangeID = null;
        this.limitStatus = null;
        this.instrumentTypeID = null;
        this.isLongOnly = null;
        this.marginCurrencyID = null;
        this.orderSizeMax = null;
        this.orderSizeMin = null;
        this.orderSizeStep = null;
        this.rateAsk = null;
        this.rateBid = null;
        this.ratePrecision = null;
        this.symbol = null;
        this.tradeStatus = null;
        this.tradingHours = null;
        this.uom = null;
        this.urlImage = null;
        this.urlInvestor = null;
        this.sector = null;
        this.priorClose = null;
        this.nameLower = null;
        this.underlyingID = null;
        this.marketState = null;
        this.minTic = null;
        this.pipMultiplier = null;
        this.tickerSymbol = null;
        this.rebateSpread = null;
        this.longOnly = null;
        this.fundamentalDataModel = null;
        
        
    }

    toString() {
        return JSON.stringify({
            baseName: this.instrumentID,
            baseName: this.name3,
            baseName: this.name,
            baseName: this.currencyID,
            baseName: this.description,
            baseName: this.exchangeID,
            baseName: this.limitStatus,
            baseName: this.instrumentTypeID,
            baseName: this.isLongOnly,
            baseName: this.marginCurrencyID,
            baseName: this.orderSizeMax,
            baseName: this.orderSizeMin,
            baseName: this.orderSizeStep,
            baseName: this.rateAsk,
            baseName: this.rateBid,
            baseName: this.ratePrecision,
            baseName: this.symbol,
            baseName: this.tradeStatus,
            baseName: this.tradingHours,
            baseName: this.uom,
            baseName: this.urlImage,
            baseName: this.urlInvestor,
            baseName: this.sector,
            baseName: this.priorClose,
            baseName: this.nameLower,
            baseName: this.underlyingID,
            baseName: this.marketState,
            baseName: this.minTic,
            baseName: this.pipMultiplier,
            baseName: this.tickerSymbol,
            baseName: this.rebateSpread,
            baseName: this.longOnly,
            baseName: this.fundamentalDataModel
            
            
        });
    }

};
module.exports = Instrument;




