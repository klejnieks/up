'use strict';





/**
* The ErrorModel model module.
* @module model/ErrorModel
* @version 1.0.1
**/

/**
* Constructs a new <code>ErrorModel</code>.
* @alias module:model/ErrorModel
* @class
* @param code
* @param message
*/

var _code = null;
var _message = null;

class ErrorModel {

    constructor() {
        //
    }

    /**
    * 
    * @member {Integer} code
    */

    get code(){ return _code; }
    set code(value){
        _code = value;
    }
    /**
    * 
    * @member {String} message
    */

    get message(){ return _message; }
    set message(value){
        _message = value;
    }

    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        
        _code = null;
        _message = null;
        
    }

    toString() {
        return JSON.stringify({
            
            _code,
            _message
            
        });
    }

};
module.exports = new ErrorModel();




