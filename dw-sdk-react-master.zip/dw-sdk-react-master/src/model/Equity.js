'use strict';




var Positions = require('./Positions'), 
Cash = require('./Cash'), 
Orders = require('./Orders'), 
Transactions = require('./Transactions');

/**
* The Equity model module.
* @module model/Equity
* @version 1.0.1
**/

/**
* Constructs a new <code>Equity</code>.
* @alias module:model/Equity
* @class
*/


class Equity {

    constructor(value) {
        this.equityValue = value.equityValue;
        this.cash = value.cash;
    }


    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        this.equityValue = null;
        this.cash = null;
        
        
    }

    toString() {
        return JSON.stringify({
            baseName: this.equityValue,
            baseName: this.cash
            
            
        });
    }

};
module.exports = Equity;




