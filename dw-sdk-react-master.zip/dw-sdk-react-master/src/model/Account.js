'use strict';





/**
* The Account model module.
* @module model/Account
* @version 1.0.1
**/

/**
* Constructs a new <code>Account</code>.
* @alias module:model/Account
* @class
*/


class Account {

    constructor(value) {
        this.nickname = value.nickname;
        this.accountID = value.accountID;
        this.accountNo = value.accountNo;
        this.accountType = value.accountType;
        this.createdWhen = value.createdWhen;
        this.currencyID = value.currencyID;
        this.freeTradeBalance = value.freeTradeBalance;
        this.goodFaithViolations = value.goodFaithViolations;
        this.ibID = value.ibID;
        this.interestFree = value.interestFree;
        this.longOnly = value.longOnly;
        this.margin = value.margin;
        this.openedWhen = value.openedWhen;
        this.patternDayTrades = value.patternDayTrades;
        this.status = value.status;
        this.tradingType = value.tradingType;
        this.commisionSchedule = value.commisionSchedule;
        this.equityValue = value.equityValue;
        this.cash = value.cash;
        this.positions = value.positions;
        this.positionsAsSymbols = value.positionsAsSymbols;
        this.positionsBySector = value.positionsBySector;
        this.orders = value.orders;
        this.lifetimePl = value.lifetimePl;
        this.lifetimePlPercent = value.lifetimePlPercent;
        this.dailyPl = value.dailyPl;
        this.dailyPlPercent = value.dailyPlPercent;
        this.hasPosition = value.hasPosition;
    }


    getPositionForSymbol(symbol) {
	var positions = _positions;
	return positions ? positions.get(symbol) : {};
}

hasPosition(symbol) {
	var positions = _positions.get(this);
	return positions ? positions.has(symbol) : false;
	}

getOrdersForSymbol(symbol) {
		return _orders.get(this).get(symbol) || [];
	}

calculateCommissionForTrade(mktPrice, investment, isSellOrder = false) {
		var shares = investment / mktPrice;
		if (shares < 1) {
			return _commissionSchedule.get(this).fractionalRate;
		}
	else {
		if (shares <= _commissionSchedule.get(this).baseShares) {
			return _commissionSchedule.get(this).baseRate;
		}
		else {
		return shares * _commissionSchedule.get(this).excessRate;
		}
	}
	}

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        this.nickname = null;
        this.accountID = null;
        this.accountNo = null;
        this.accountType = null;
        this.createdWhen = null;
        this.currencyID = null;
        this.freeTradeBalance = null;
        this.goodFaithViolations = null;
        this.ibID = null;
        this.interestFree = null;
        this.longOnly = null;
        this.margin = null;
        this.openedWhen = null;
        this.patternDayTrades = null;
        this.status = null;
        this.tradingType = null;
        this.commisionSchedule = null;
        this.equityValue = null;
        this.cash = null;
        this.positions = null;
        this.positionsAsSymbols = null;
        this.positionsBySector = null;
        this.orders = null;
        this.lifetimePl = null;
        this.lifetimePlPercent = null;
        this.dailyPl = null;
        this.dailyPlPercent = null;
        this.hasPosition = null;
        
        
    }

    toString() {
        return JSON.stringify({
            baseName: this.nickname,
            baseName: this.accountID,
            baseName: this.accountNo,
            baseName: this.accountType,
            baseName: this.createdWhen,
            baseName: this.currencyID,
            baseName: this.freeTradeBalance,
            baseName: this.goodFaithViolations,
            baseName: this.ibID,
            baseName: this.interestFree,
            baseName: this.longOnly,
            baseName: this.margin,
            baseName: this.openedWhen,
            baseName: this.patternDayTrades,
            baseName: this.status,
            baseName: this.tradingType,
            baseName: this.commisionSchedule,
            baseName: this.equityValue,
            baseName: this.cash,
            baseName: this.positions,
            baseName: this.positionsAsSymbols,
            baseName: this.positionsBySector,
            baseName: this.orders,
            baseName: this.lifetimePl,
            baseName: this.lifetimePlPercent,
            baseName: this.dailyPl,
            baseName: this.dailyPlPercent,
            baseName: this.hasPosition
            
            
        });
    }

};
module.exports = Account;




