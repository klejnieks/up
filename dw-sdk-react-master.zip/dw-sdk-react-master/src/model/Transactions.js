'use strict';





/**
* The Transactions model module.
* @module model/Transactions
* @version 1.0.1
**/

/**
* Constructs a new <code>Transactions</code>.
* @alias module:model/Transactions
* @class
*/


class Transactions {

    constructor(value) {
        this.orderID = value.orderID;
        this.orderNo = value.orderNo;
        this.symbol = value.symbol;
        this.cumQty = value.cumQty;
        this.orderStatus = value.orderStatus;
        this.orderType = value.orderType;
        this.orderQty = value.orderQty;
        this.orderCashAmt = value.orderCashAmt;
        this.createdWhen = value.createdWhen;
        this.updatedReason = value.updatedReason;
        this.side = value.side;
        this.commission = value.commission;
        this.executedWhen = value.executedWhen;
        this.stopPrice = value.stopPrice;
    }


    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        this.orderID = null;
        this.orderNo = null;
        this.symbol = null;
        this.cumQty = null;
        this.orderStatus = null;
        this.orderType = null;
        this.orderQty = null;
        this.orderCashAmt = null;
        this.createdWhen = null;
        this.updatedReason = null;
        this.side = null;
        this.commission = null;
        this.executedWhen = null;
        this.stopPrice = null;
        
        
    }

    toString() {
        return JSON.stringify({
            baseName: this.orderID,
            baseName: this.orderNo,
            baseName: this.symbol,
            baseName: this.cumQty,
            baseName: this.orderStatus,
            baseName: this.orderType,
            baseName: this.orderQty,
            baseName: this.orderCashAmt,
            baseName: this.createdWhen,
            baseName: this.updatedReason,
            baseName: this.side,
            baseName: this.commission,
            baseName: this.executedWhen,
            baseName: this.stopPrice
            
            
        });
    }

};
module.exports = Transactions;




