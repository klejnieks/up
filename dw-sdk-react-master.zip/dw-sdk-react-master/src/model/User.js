'use strict';




var Account = require('./Account');

/**
* The User model module.
* @module model/User
* @version 1.0.1
**/

/**
* Constructs a new <code>User</code>.
* @alias module:model/User
* @class
*/

var _name = null;
var _appTypeID = null;
var _accounts = null;
var _selectedAccount = null;
var _guest = null;
var _statusMsg = null;
var _referralCode = null;
var _featureToggle = null;
var _ackSignedWhen = null;
var _addressLine1 = null;
var _avatarUrl = null;
var _city = null;
var _coinBalance = null;
var _commisionRate = null;
var _countryID = null;
var _displayName = null;
var _emailAddress1 = null;
var _firstName = null;
var _gender = null;
var _languageID = null;
var _lastName = null;
var _phoneHome = null;
var _sessionKey = null;
var _stateProvince = null;
var _userID = null;
var _username = null;
var _wlpID = null;
var _zipPostalCode = null;
var _status = null;
var _usCitizen = null;
var _updatedWhen = null;
var _lastLoginWhen = null;
var _rebateCfdValue = null;
var _rebateEquityValue = null;
var _rebateFxValue = null;
var _brandAmbassador = null;
var _employerBusiness = null;
var _employmentStatus = null;
var _statementPrint = null;
var _confirmPrint = null;
var _citizenship = null;
var _createdWhen = null;
var _addressProofReviewWhen = null;
var _approvedWhen = null;
var _approvedBy = null;
var _kycWhen = null;
var _pictureReviewBy = null;
var _pictureReviewWhen = null;
var _annualIncome = null;
var _userAttributes = null;

class User {

    constructor() {
        //
    }

    /**
    * 
    * @member {String} name
    */

    get name(){ return _name; }
    set name(value){
        _name = value;
    }
    /**
    * 
    * @member {Number} appTypeID
    */

    get appTypeID(){ return _appTypeID; }
    set appTypeID(value){
        _appTypeID = value;
    }
    /**
    * 
    * @member {Array.<module:model/Account>} accounts
    */

    get accounts(){ return _accounts; }
    set accounts(value){
        _accounts = value.map(account => {
		return new Account(account);
	});
    }
    /**
    * 
    * @member {Object} selectedAccount
    */

    get selectedAccount(){ return _selectedAccount; }
    set selectedAccount(value){
        if(id === null) return;
	for (let account of _accounts) {
		if (account.accountID === id) {
			_selectedAccount = account;
			return;
		}
	}
	throw new Error('[UserModel] The account ID specified to set was not found in the users list of accounts.');
    }
    /**
    * 
    * @member {Boolean} guest
    */

    get guest(){ return _guest; }
    set guest(value){
        _guest = value;
    }
    /**
    * 
    * @member {String} statusMsg
    */

    get statusMsg(){ return _statusMsg; }
    set statusMsg(value){
        _statusMsg = value;
    }
    /**
    * 
    * @member {String} referralCode
    */

    get referralCode(){ return _referralCode; }
    set referralCode(value){
        _referralCode = value;
    }
    /**
    * 
    * @member {Object} featureToggle
    */

    get featureToggle(){ return _featureToggle; }
    set featureToggle(value){
        _featureToggle = value;
    }
    /**
    * 
    * @member {String} ackSignedWhen
    */

    get ackSignedWhen(){ return _ackSignedWhen; }
    set ackSignedWhen(value){
        _ackSignedWhen = value;
    }
    /**
    * 
    * @member {String} addressLine1
    */

    get addressLine1(){ return _addressLine1; }
    set addressLine1(value){
        _addressLine1 = value;
    }
    /**
    * 
    * @member {String} avatarUrl
    */

    get avatarUrl(){ return _avatarUrl; }
    set avatarUrl(value){
        _avatarUrl = value;
    }
    /**
    * 
    * @member {String} city
    */

    get city(){ return _city; }
    set city(value){
        _city = value;
    }
    /**
    * 
    * @member {String} coinBalance
    */

    get coinBalance(){ return _coinBalance; }
    set coinBalance(value){
        _coinBalance = value;
    }
    /**
    * 
    * @member {String} commisionRate
    */

    get commisionRate(){ return _commisionRate; }
    set commisionRate(value){
        _commisionRate = value;
    }
    /**
    * 
    * @member {String} countryID
    */

    get countryID(){ return _countryID; }
    set countryID(value){
        _countryID = value;
    }
    /**
    * 
    * @member {String} displayName
    */

    get displayName(){ return _displayName; }
    set displayName(value){
        _displayName = value;
    }
    /**
    * 
    * @member {String} emailAddress1
    */

    get emailAddress1(){ return _emailAddress1; }
    set emailAddress1(value){
        _emailAddress1 = value;
    }
    /**
    * 
    * @member {String} firstName
    */

    get firstName(){ return _firstName; }
    set firstName(value){
        _firstName = value;
    }
    /**
    * 
    * @member {String} gender
    */

    get gender(){ return _gender; }
    set gender(value){
        _gender = value;
    }
    /**
    * 
    * @member {String} languageID
    */

    get languageID(){ return _languageID; }
    set languageID(value){
        _languageID = value;
    }
    /**
    * 
    * @member {String} lastName
    */

    get lastName(){ return _lastName; }
    set lastName(value){
        _lastName = value;
    }
    /**
    * 
    * @member {String} phoneHome
    */

    get phoneHome(){ return _phoneHome; }
    set phoneHome(value){
        _phoneHome = value;
    }
    /**
    * 
    * @member {String} sessionKey
    */

    get sessionKey(){ return _sessionKey; }
    set sessionKey(value){
        _sessionKey = value;
    }
    /**
    * 
    * @member {String} stateProvince
    */

    get stateProvince(){ return _stateProvince; }
    set stateProvince(value){
        _stateProvince = value;
    }
    /**
    * 
    * @member {String} userID
    */

    get userID(){ return _userID; }
    set userID(value){
        _userID = value;
    }
    /**
    * 
    * @member {String} username
    */

    get username(){ return _username; }
    set username(value){
        _username = value;
    }
    /**
    * 
    * @member {String} wlpID
    */

    get wlpID(){ return _wlpID; }
    set wlpID(value){
        _wlpID = value;
    }
    /**
    * 
    * @member {String} zipPostalCode
    */

    get zipPostalCode(){ return _zipPostalCode; }
    set zipPostalCode(value){
        _zipPostalCode = value;
    }
    /**
    * 
    * @member {Integer} status
    */

    get status(){ return _status; }
    set status(value){
        _status = value;
    }
    /**
    * 
    * @member {Boolean} usCitizen
    */

    get usCitizen(){ return _usCitizen; }
    set usCitizen(value){
        _usCitizen = value;
    }
    /**
    * 
    * @member {String} updatedWhen
    */

    get updatedWhen(){ return _updatedWhen; }
    set updatedWhen(value){
        _updatedWhen = value;
    }
    /**
    * 
    * @member {String} lastLoginWhen
    */

    get lastLoginWhen(){ return _lastLoginWhen; }
    set lastLoginWhen(value){
        if (typeof value === "string") {
		_lastLoginWhen = new Date(value);
	}
	else {
		_lastLoginWhen = value;
	}
    }
    /**
    * 
    * @member {Integer} rebateCfdValue
    */

    get rebateCfdValue(){ return _rebateCfdValue; }
    set rebateCfdValue(value){
        _rebateCfdValue = value;
    }
    /**
    * 
    * @member {Integer} rebateEquityValue
    */

    get rebateEquityValue(){ return _rebateEquityValue; }
    set rebateEquityValue(value){
        _rebateEquityValue = value;
    }
    /**
    * 
    * @member {Integer} rebateFxValue
    */

    get rebateFxValue(){ return _rebateFxValue; }
    set rebateFxValue(value){
        _rebateFxValue = value;
    }
    /**
    * 
    * @member {Boolean} brandAmbassador
    */

    get brandAmbassador(){ return _brandAmbassador; }
    set brandAmbassador(value){
        _brandAmbassador = value;
    }
    /**
    * 
    * @member {String} employerBusiness
    */

    get employerBusiness(){ return _employerBusiness; }
    set employerBusiness(value){
        _employerBusiness = value;
    }
    /**
    * 
    * @member {String} employmentStatus
    */

    get employmentStatus(){ return _employmentStatus; }
    set employmentStatus(value){
        _employmentStatus = value;
    }
    /**
    * 
    * @member {Boolean} statementPrint
    */

    get statementPrint(){ return _statementPrint; }
    set statementPrint(value){
        _statementPrint = value;
    }
    /**
    * 
    * @member {Boolean} confirmPrint
    */

    get confirmPrint(){ return _confirmPrint; }
    set confirmPrint(value){
        _confirmPrint = value;
    }
    /**
    * 
    * @member {String} citizenship
    */

    get citizenship(){ return _citizenship; }
    set citizenship(value){
        _citizenship = value;
    }
    /**
    * 
    * @member {String} createdWhen
    */

    get createdWhen(){ return _createdWhen; }
    set createdWhen(value){
        _createdWhen = value;
    }
    /**
    * 
    * @member {String} addressProofReviewWhen
    */

    get addressProofReviewWhen(){ return _addressProofReviewWhen; }
    set addressProofReviewWhen(value){
        _addressProofReviewWhen = value;
    }
    /**
    * 
    * @member {String} approvedWhen
    */

    get approvedWhen(){ return _approvedWhen; }
    set approvedWhen(value){
        _approvedWhen = value;
    }
    /**
    * 
    * @member {String} approvedBy
    */

    get approvedBy(){ return _approvedBy; }
    set approvedBy(value){
        _approvedBy = value;
    }
    /**
    * 
    * @member {String} kycWhen
    */

    get kycWhen(){ return _kycWhen; }
    set kycWhen(value){
        _kycWhen = value;
    }
    /**
    * 
    * @member {String} pictureReviewBy
    */

    get pictureReviewBy(){ return _pictureReviewBy; }
    set pictureReviewBy(value){
        _pictureReviewBy = value;
    }
    /**
    * 
    * @member {String} pictureReviewWhen
    */

    get pictureReviewWhen(){ return _pictureReviewWhen; }
    set pictureReviewWhen(value){
        _pictureReviewWhen = value;
    }
    /**
    * 
    * @member {String} annualIncome
    */

    get annualIncome(){ return _annualIncome; }
    set annualIncome(value){
        _annualIncome = value;
    }
    /**
    * 
    * @member {Object} userAttributes
    */

    get userAttributes(){ return _userAttributes; }
    set userAttributes(value){
        _userAttributes = value;
    }

    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        
        _name = null;
        _appTypeID = null;
        _accounts = null;
        _selectedAccount = null;
        _guest = null;
        _statusMsg = null;
        _referralCode = null;
        _featureToggle = null;
        _ackSignedWhen = null;
        _addressLine1 = null;
        _avatarUrl = null;
        _city = null;
        _coinBalance = null;
        _commisionRate = null;
        _countryID = null;
        _displayName = null;
        _emailAddress1 = null;
        _firstName = null;
        _gender = null;
        _languageID = null;
        _lastName = null;
        _phoneHome = null;
        _sessionKey = null;
        _stateProvince = null;
        _userID = null;
        _username = null;
        _wlpID = null;
        _zipPostalCode = null;
        _status = null;
        _usCitizen = null;
        _updatedWhen = null;
        _lastLoginWhen = null;
        _rebateCfdValue = null;
        _rebateEquityValue = null;
        _rebateFxValue = null;
        _brandAmbassador = null;
        _employerBusiness = null;
        _employmentStatus = null;
        _statementPrint = null;
        _confirmPrint = null;
        _citizenship = null;
        _createdWhen = null;
        _addressProofReviewWhen = null;
        _approvedWhen = null;
        _approvedBy = null;
        _kycWhen = null;
        _pictureReviewBy = null;
        _pictureReviewWhen = null;
        _annualIncome = null;
        _userAttributes = null;
        
    }

    toString() {
        return JSON.stringify({
            
            _name,
            _appTypeID,
            _accounts,
            _selectedAccount,
            _guest,
            _statusMsg,
            _referralCode,
            _featureToggle,
            _ackSignedWhen,
            _addressLine1,
            _avatarUrl,
            _city,
            _coinBalance,
            _commisionRate,
            _countryID,
            _displayName,
            _emailAddress1,
            _firstName,
            _gender,
            _languageID,
            _lastName,
            _phoneHome,
            _sessionKey,
            _stateProvince,
            _userID,
            _username,
            _wlpID,
            _zipPostalCode,
            _status,
            _usCitizen,
            _updatedWhen,
            _lastLoginWhen,
            _rebateCfdValue,
            _rebateEquityValue,
            _rebateFxValue,
            _brandAmbassador,
            _employerBusiness,
            _employmentStatus,
            _statementPrint,
            _confirmPrint,
            _citizenship,
            _createdWhen,
            _addressProofReviewWhen,
            _approvedWhen,
            _approvedBy,
            _kycWhen,
            _pictureReviewBy,
            _pictureReviewWhen,
            _annualIncome,
            _userAttributes
            
        });
    }

};
module.exports = new User();




