'use strict';





/**
* The Positions model module.
* @module model/Positions
* @version 1.0.1
**/

/**
* Constructs a new <code>Positions</code>.
* @alias module:model/Positions
* @class
*/


class Positions {

    constructor(value) {
        this.symbol = value.symbol;
        this.instrumentID = value.instrumentID;
        this.openQty = value.openQty;
        this.costBasis = value.costBasis;
        this.marketValue = value.marketValue;
        this.side = value.side;
        this.priorClose = value.priorClose;
        this.availableForTradingQty = value.availableForTradingQty;
        this.avgPrice = value.avgPrice;
        this.mktPrice = value.mktPrice;
        this.unrealizedPL = value.unrealizedPL;
        this.unrealizedDayPLPercent = value.unrealizedDayPLPercent;
        this.unrealizedDayPL = value.unrealizedDayPL;
    }


    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        this.symbol = null;
        this.instrumentID = null;
        this.openQty = null;
        this.costBasis = null;
        this.marketValue = null;
        this.side = null;
        this.priorClose = null;
        this.availableForTradingQty = null;
        this.avgPrice = null;
        this.mktPrice = null;
        this.unrealizedPL = null;
        this.unrealizedDayPLPercent = null;
        this.unrealizedDayPL = null;
        
        
    }

    toString() {
        return JSON.stringify({
            baseName: this.symbol,
            baseName: this.instrumentID,
            baseName: this.openQty,
            baseName: this.costBasis,
            baseName: this.marketValue,
            baseName: this.side,
            baseName: this.priorClose,
            baseName: this.availableForTradingQty,
            baseName: this.avgPrice,
            baseName: this.mktPrice,
            baseName: this.unrealizedPL,
            baseName: this.unrealizedDayPLPercent,
            baseName: this.unrealizedDayPL
            
            
        });
    }

};
module.exports = Positions;




