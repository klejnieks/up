'use strict';





/**
* The FeatureToggle model module.
* @module model/FeatureToggle
* @version 1.0.1
**/

/**
* Constructs a new <code>FeatureToggle</code>.
* @alias module:model/FeatureToggle
* @class
*/


class FeatureToggle {

    constructor(value) {
        this.featureToggleID = value.featureToggleID;
        this.enabled = value.enabled;
    }


    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        this.featureToggleID = null;
        this.enabled = null;
        
        
    }

    toString() {
        return JSON.stringify({
            baseName: this.featureToggleID,
            baseName: this.enabled
            
            
        });
    }

};
module.exports = FeatureToggle;




