'use strict';





/**
* The Fundamental model module.
* @module model/Fundamental
* @version 1.0.1
**/

/**
* Constructs a new <code>Fundamental</code>.
* @alias module:model/Fundamental
* @class
*/


class Fundamental {

    constructor(value) {
        this.instrumentID = value.instrumentID;
        this.symbol = value.symbol;
        this.companyName = value.companyName;
        this.yesterdayClose = value.yesterdayClose;
        this.openPrice = value.openPrice;
        this.bidPrice = value.bidPrice;
        this.askPrice = value.askPrice;
        this.lowPrice = value.lowPrice;
        this.highPrice = value.highPrice;
        this.fiftyTwoWeekLowPrice = value.fiftyTwoWeekLowPrice;
        this.fiftyTwoWeekHighPrice = value.fiftyTwoWeekHighPrice;
        this.cumulativeVolume = value.cumulativeVolume;
        this.thirtyDayAvgVolume = value.thirtyDayAvgVolume;
        this.marketCap = value.marketCap;
        this.peRatio = value.peRatio;
        this.dividendYield = value.dividendYield;
        this.earningsPerShare = value.earningsPerShare;
        this.dividend = value.dividend;
    }


    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        this.instrumentID = null;
        this.symbol = null;
        this.companyName = null;
        this.yesterdayClose = null;
        this.openPrice = null;
        this.bidPrice = null;
        this.askPrice = null;
        this.lowPrice = null;
        this.highPrice = null;
        this.fiftyTwoWeekLowPrice = null;
        this.fiftyTwoWeekHighPrice = null;
        this.cumulativeVolume = null;
        this.thirtyDayAvgVolume = null;
        this.marketCap = null;
        this.peRatio = null;
        this.dividendYield = null;
        this.earningsPerShare = null;
        this.dividend = null;
        
        
    }

    toString() {
        return JSON.stringify({
            baseName: this.instrumentID,
            baseName: this.symbol,
            baseName: this.companyName,
            baseName: this.yesterdayClose,
            baseName: this.openPrice,
            baseName: this.bidPrice,
            baseName: this.askPrice,
            baseName: this.lowPrice,
            baseName: this.highPrice,
            baseName: this.fiftyTwoWeekLowPrice,
            baseName: this.fiftyTwoWeekHighPrice,
            baseName: this.cumulativeVolume,
            baseName: this.thirtyDayAvgVolume,
            baseName: this.marketCap,
            baseName: this.peRatio,
            baseName: this.dividendYield,
            baseName: this.earningsPerShare,
            baseName: this.dividend
            
            
        });
    }

};
module.exports = Fundamental;




