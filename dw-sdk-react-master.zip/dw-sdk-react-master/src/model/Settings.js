'use strict';




var Environments = require('./Environments');

/**
* The Settings model module.
* @module model/Settings
* @version 1.0.1
**/

/**
* Constructs a new <code>Settings</code>.
* @alias module:model/Settings
* @class
*/

var _marketState = 2;
var _wlpid = 'dw';
var _quotesRefreshRate = 2000;
var _quotesFailureThreshold = 60000;
var _quotesFailureTime = 3000;
var _accountRefreshRate = 10000;
var _maxOrderStatusAttempts = 3;
var _starterFunds = 10000;
var _defaultLanguageID = 'en_US';
var _serviceHost = Environments.PROD;

class Settings {

    constructor() {
        //
    }

    /**
    * 
    * @member {Number} marketState
    */

    get marketState(){ return _marketState; }
    set marketState(value){
        _marketState = value;
    }
    /**
    * 
    * @member {String} wlpid
    */

    get wlpid(){ return _wlpid; }
    set wlpid(value){
        _wlpid = value;
    }
    /**
    * 
    * @member {Number} quotesRefreshRate
    */

    get quotesRefreshRate(){ return _quotesRefreshRate; }
    set quotesRefreshRate(value){
        _quotesRefreshRate = value;
    }
    /**
    * 
    * @member {Number} quotesFailureThreshold
    */

    get quotesFailureThreshold(){ return _quotesFailureThreshold; }
    set quotesFailureThreshold(value){
        _quotesFailureThreshold = value;
    }
    /**
    * 
    * @member {Number} quotesFailureTime
    */

    get quotesFailureTime(){ return _quotesFailureTime; }
    set quotesFailureTime(value){
        _quotesFailureTime = value;
    }
    /**
    * 
    * @member {Number} accountRefreshRate
    */

    get accountRefreshRate(){ return _accountRefreshRate; }
    set accountRefreshRate(value){
        _accountRefreshRate = value;
    }
    /**
    * 
    * @member {Number} maxOrderStatusAttempts
    */

    get maxOrderStatusAttempts(){ return _maxOrderStatusAttempts; }
    set maxOrderStatusAttempts(value){
        _maxOrderStatusAttempts = value;
    }
    /**
    * 
    * @member {Number} starterFunds
    */

    get starterFunds(){ return _starterFunds; }
    set starterFunds(value){
        _starterFunds = value;
    }
    /**
    * 
    * @member {String} defaultLanguageID
    */

    get defaultLanguageID(){ return _defaultLanguageID; }
    set defaultLanguageID(value){
        _defaultLanguageID = value;
    }
    /**
    * 
    * @member {String} serviceHost
    */

    get serviceHost(){ return _serviceHost; }
    set serviceHost(value){
        _serviceHost = value;
    }

    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        
        _marketState = null;
        _wlpid = null;
        _quotesRefreshRate = null;
        _quotesFailureThreshold = null;
        _quotesFailureTime = null;
        _accountRefreshRate = null;
        _maxOrderStatusAttempts = null;
        _starterFunds = null;
        _defaultLanguageID = null;
        _serviceHost = null;
        
    }

    toString() {
        return JSON.stringify({
            
            _marketState,
            _wlpid,
            _quotesRefreshRate,
            _quotesFailureThreshold,
            _quotesFailureTime,
            _accountRefreshRate,
            _maxOrderStatusAttempts,
            _starterFunds,
            _defaultLanguageID,
            _serviceHost
            
        });
    }

};
module.exports = new Settings();




