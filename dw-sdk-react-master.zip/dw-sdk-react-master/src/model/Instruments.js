'use strict';




var Instrument = require('./Instrument');

/**
* The Instruments model module.
* @module model/Instruments
* @version 1.0.1
**/

/**
* Constructs a new <code>Instruments</code>.
* @alias module:model/Instruments
* @class
*/


class Instruments {

    constructor() {
        //
    }


    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        
        
    }

    toString() {
        return JSON.stringify({
            
            
        });
    }

};
module.exports = new Instruments();




