'use strict';





/**
* The Cash model module.
* @module model/Cash
* @version 1.0.1
**/

/**
* Constructs a new <code>Cash</code>.
* @alias module:model/Cash
* @class
*/


class Cash {

    constructor(value) {
        this.cashAvailableForTrade = value.cashAvailableForTrade;
        this.cashAvailableForWithdrawal = value.cashAvailableForWithdrawal;
        this.cashBalance = value.cashBalance;
    }


    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        this.cashAvailableForTrade = null;
        this.cashAvailableForWithdrawal = null;
        this.cashBalance = null;
        
        
    }

    toString() {
        return JSON.stringify({
            baseName: this.cashAvailableForTrade,
            baseName: this.cashAvailableForWithdrawal,
            baseName: this.cashBalance
            
            
        });
    }

};
module.exports = Cash;




