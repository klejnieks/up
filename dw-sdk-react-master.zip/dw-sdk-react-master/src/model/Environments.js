'use strict';


/**
 * Enum class Environments.
 * @enum {}
 * @readonly
 */
const Environments = {

    /**
     * value: "UAT"
     * @const
     */
    "UAT": "UAT",

    /**
     * value: "PROD"
     * @const
     */
    "PROD": "PROD"
};

module.exports = Environments;


