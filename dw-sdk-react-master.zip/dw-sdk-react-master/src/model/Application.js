'use strict';




var Environments = require('./Environments');

/**
* The Application model module.
* @module model/Application
* @version 1.4.105
**/

/**
* Constructs a new <code>Application</code>.
* @alias module:model/Application
* @class
*/


class Application {

    constructor(value) {
        this.marketState = value.marketState;
        this.wlpid = value.wlpid;
        this.quotesFailureThreshold = value.quotesFailureThreshold || 60000;
        this.quotesFailureTime = value.quotesFailureTime || 3000;
        this.accountRefreshRate = value.accountRefreshRate || 10000;
        this.maxOrderStatusAttempts = value.maxOrderStatusAttempts || 3;
        this.starterFunds = value.starterFunds || 10000;
        this.defaultLanguageID = value.defaultLanguageID || 'en_US';
        this.serviceHost = value.serviceHost || Environments.UAT;
    }


    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        this.marketState = undefined;
        this.wlpid = undefined;
        this.quotesFailureThreshold = undefined;
        this.quotesFailureTime = undefined;
        this.accountRefreshRate = undefined;
        this.maxOrderStatusAttempts = undefined;
        this.starterFunds = undefined;
        this.defaultLanguageID = undefined;
        this.serviceHost = undefined;
        
        
    }

    toString() {
        return JSON.stringify({
            baseName: this.marketState,
            baseName: this.wlpid,
            baseName: this.quotesFailureThreshold,
            baseName: this.quotesFailureTime,
            baseName: this.accountRefreshRate,
            baseName: this.maxOrderStatusAttempts,
            baseName: this.starterFunds,
            baseName: this.defaultLanguageID,
            baseName: this.serviceHost
            
            
        });
    }

};
module.exports = Application;




