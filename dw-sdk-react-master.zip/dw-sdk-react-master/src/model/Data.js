'use strict';






/**
* The Data model module.
* @module model/Data
* @version 1.4.81
**/

/**
* Constructs a new <code>Data</code>.
* @alias module:model/Data
* @class
*/

var _languageID = undefined;
var _wlpID = undefined;
var _utm_source = undefined;
var _utm_campaign = undefined;
var _utm_content = undefined;
var _utm_medium = undefined;
var _utm_term = undefined;
var _referralCode = undefined;

class Data {

    constructor() {
        //
    }

    /**
    * Media's name
    * @member {String} languageID
    */

    get languageID(){ return _languageID; }
    set languageID(value){
        _languageID = value;
    }
    /**
    * username for forgot password
    * @member {String} wlpID
    */

    get wlpID(){ return _wlpID; }
    set wlpID(value){
        _wlpID = value;
    }
    /**
    * username for forgot password
    * @member {String} utm_source
    */

    get utm_source(){ return _utm_source; }
    set utm_source(value){
        _utm_source = value;
    }
    /**
    * username for forgot password
    * @member {String} utm_campaign
    */

    get utm_campaign(){ return _utm_campaign; }
    set utm_campaign(value){
        _utm_campaign = value;
    }
    /**
    * username for forgot password
    * @member {String} utm_content
    */

    get utm_content(){ return _utm_content; }
    set utm_content(value){
        _utm_content = value;
    }
    /**
    * username for forgot password
    * @member {String} utm_medium
    */

    get utm_medium(){ return _utm_medium; }
    set utm_medium(value){
        _utm_medium = value;
    }
    /**
    * username for forgot password
    * @member {String} utm_term
    */

    get utm_term(){ return _utm_term; }
    set utm_term(value){
        _utm_term = value;
    }
    /**
    * username for forgot password
    * @member {String} referralCode
    */

    get referralCode(){ return _referralCode; }
    set referralCode(value){
        _referralCode = value;
    }

    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        _languageID = undefined;
        _wlpID = undefined;
        _utm_source = undefined;
        _utm_campaign = undefined;
        _utm_content = undefined;
        _utm_medium = undefined;
        _utm_term = undefined;
        _referralCode = undefined;
    }

    toString() {
        return JSON.stringify({
            languageID,wlpID,utm_source,utm_campaign,utm_content,utm_medium,utm_term,referralCode,
        });
    }

};
module.exports = new Data();




