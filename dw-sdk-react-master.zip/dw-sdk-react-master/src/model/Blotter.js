'use strict';




var Equity = require('./Equity'), 
Cash = require('./Cash'), 
Orders = require('./Orders'), 
Transactions = require('./Transactions');

/**
* The Blotter model module.
* @module model/Blotter
* @version 1.0.1
**/

/**
* Constructs a new <code>Blotter</code>.
* @alias module:model/Blotter
* @class
*/


class Blotter {

    constructor(value) {
        this.accountID = value.accountID;
        this.accountNo = value.accountNo;
        this.cash = value.cash;
    }


    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        this.accountID = null;
        this.accountNo = null;
        this.cash = null;
        
        
    }

    toString() {
        return JSON.stringify({
            baseName: this.accountID,
            baseName: this.accountNo,
            baseName: this.cash
            
            
        });
    }

};
module.exports = Blotter;




