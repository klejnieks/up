'use strict';




var FeatureToggle = require('./FeatureToggle');

/**
* The FeatureToggles model module.
* @module model/FeatureToggles
* @version 1.0.1
**/

/**
* Constructs a new <code>FeatureToggles</code>.
* @alias module:model/FeatureToggles
* @class
*/


class FeatureToggles {

    constructor() {
        //
    }


    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        
        
    }

    toString() {
        return JSON.stringify({
            
            
        });
    }

};
module.exports = new FeatureToggles();




