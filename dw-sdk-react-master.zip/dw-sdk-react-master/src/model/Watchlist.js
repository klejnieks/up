'use strict';





/**
* The Watchlist model module.
* @module model/Watchlist
* @version 1.0.1
**/

/**
* Constructs a new <code>Watchlist</code>.
* @alias module:model/Watchlist
* @class
*/

var _userID = null;
var _key = null;
var _value = null;

class Watchlist {

    constructor() {
        //
    }

    /**
    * 
    * @member {String} userID
    */

    get userID(){ return _userID; }
    set userID(value){
        _userID = value;
    }
    /**
    * 
    * @member {String} key
    */

    get key(){ return _key; }
    set key(value){
        _key = value;
    }
    /**
    * 
    * @member {String} value
    */

    get value(){ return _value; }
    set value(value){
        _value = value;
    }

    

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        
        _userID = null;
        _key = null;
        _value = null;
        
    }

    toString() {
        return JSON.stringify({
            
            _userID,
            _key,
            _value
            
        });
    }

};
module.exports = new Watchlist();




