# drivewealth-sdk-javascript

DrivewealthSdk - JavaScript client for drivewealth-sdk-javascript
DriveWealth SDK for client application implementation

- API version: 1.0.1
- Package version: 1.0.1
- Build date: 2016-06-29T12:24:13.472-04:00
- Build package: class io.swagger.codegen.languages.JavascriptClientCodegen
For more information, please visit [http://drivewealth.com](http://drivewealth.com)

## Installation

### For [Node.js](https://nodejs.org/)

#### npm

To publish the library as a [npm](https://www.npmjs.com/),
please follow the procedure in ["Publishing npm packages"](https://docs.npmjs.com/getting-started/publishing-npm-packages).

Then install it via:

```shell
npm install drivewealth-sdk-javascript --save
```

#### git
#
If the library is hosted at a git repository, e.g.
https://github.com/GIT_USER_ID/GIT_REPO_ID
then install it via:

```shell
    npm install GIT_USER_ID/GIT_REPO_ID --save
```

### For browser

The library also works in the browser environment via npm and [browserify](http://browserify.org/). After following
the above steps with Node.js and installing browserify with `npm install -g browserify`,
perform the following (assuming *main.js* is your entry file):

```shell
browserify main.js > bundle.js
```

Then include *bundle.js* in the HTML pages.

## Getting Started

####nb: DWSDK comes with a series of utilities, some are embeded from DW and some are external dependencies such as
[WatchJS](https://github.com/melanke/Watch.JS) which is used for observing property changes. These dependencies are already included
with the DWSDK package and will be automatically installed as part of the DWSDK setup process. 


Please follow the [installation](#installation) instruction and execute the following JS code:

```javascript
var DrivewealthSdk = require('drivewealth-sdk-javascript');

var api = new DrivewealthSdk.AccountsServiceApi()

var userID = "userID_example"; // {String} ID of user to fetch

var accountID = "accountID_example"; // {String} ID of user to fetch

api.getAccountByID(userID, accountID).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});


```

## Documentation for API Endpoints

All URIs are relative to *http://api.drivewealth.io/v1*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*DrivewealthSdk.AccountsServiceApi* | [**getAccountByID**](docs/AccountsServiceApi.md#getAccountByID) | **GET** /users/{{userID}}/accounts/{{accountID}} | 
*DrivewealthSdk.AccountsServiceApi* | [**getAccounts**](docs/AccountsServiceApi.md#getAccounts) | **GET** /users/{{userID}}/accounts | 
*DrivewealthSdk.AccountsServiceApi* | [**getSummary**](docs/AccountsServiceApi.md#getSummary) | **GET** /users/{{userID}}/accountSummary/{{accountID}} | 
*DrivewealthSdk.FeatureTogglesServiceApi* | [**getFeatureToggles**](docs/FeatureTogglesServiceApi.md#getFeatureToggles) | **GET** /featureToggles | 
*DrivewealthSdk.InstrumentServiceApi* | [**getBarsData**](docs/InstrumentServiceApi.md#getBarsData) | **GET** /bars?instrumentID&#x3D;{{params}} | 
*DrivewealthSdk.InstrumentServiceApi* | [**getInstrumentByID**](docs/InstrumentServiceApi.md#getInstrumentByID) | **GET** /instruments/{{instrumentID}}?options&#x3D;F | 
*DrivewealthSdk.InstrumentServiceApi* | [**getInstrumentBySymbols**](docs/InstrumentServiceApi.md#getInstrumentBySymbols) | **GET** /instruments/?symbols&#x3D;{{symbols}} | 
*DrivewealthSdk.InstrumentServiceApi* | [**getInstruments**](docs/InstrumentServiceApi.md#getInstruments) | **GET** /instruments?{{params}} | 
*DrivewealthSdk.OrderServiceApi* | [**cancel**](docs/OrderServiceApi.md#cancel) | **DELETE** /orders/{{orderID}} | 
*DrivewealthSdk.OrderServiceApi* | [**submitBasketOrders**](docs/OrderServiceApi.md#submitBasketOrders) | **POST** /orders | 
*DrivewealthSdk.UserServiceApi* | [**edit**](docs/UserServiceApi.md#edit) | **PUT** /users/{{userID}} | 
*DrivewealthSdk.UserServiceApi* | [**forgotPassword**](docs/UserServiceApi.md#forgotPassword) | **POST** /users/passwords{{username}} | 
*DrivewealthSdk.UserServiceApi* | [**getSetting**](docs/UserServiceApi.md#getSetting) | **GET** /users/{{userID}}/settings/{{key}} | 
*DrivewealthSdk.UserServiceApi* | [**getStatus**](docs/UserServiceApi.md#getStatus) | **GET** /users/{{userID}}/status | 
*DrivewealthSdk.UserServiceApi* | [**getUser**](docs/UserServiceApi.md#getUser) | **GET** /userSessions/{{sessionKey}} | 
*DrivewealthSdk.UserServiceApi* | [**getUserByUserID**](docs/UserServiceApi.md#getUserByUserID) | **GET** /users/{{id}} | 
*DrivewealthSdk.UserServiceApi* | [**heartbeat**](docs/UserServiceApi.md#heartbeat) | **PUT** /userSessions/{{sessionKey}}?action&#x3D;heartbeat | 
*DrivewealthSdk.UserServiceApi* | [**isUsernameAvailable**](docs/UserServiceApi.md#isUsernameAvailable) | **GET** /users?username&#x3D;{{username}} | 
*DrivewealthSdk.UserServiceApi* | [**login**](docs/UserServiceApi.md#login) | **POST** /userSessions | 
*DrivewealthSdk.UserServiceApi* | [**resetPassword**](docs/UserServiceApi.md#resetPassword) | **PUT** /users/passwords/{{code}} | 
*DrivewealthSdk.UserServiceApi* | [**saveSetting**](docs/UserServiceApi.md#saveSetting) | **POST** /users/{{userID}}/settings | 
*DrivewealthSdk.UserServiceApi* | [**setPassword**](docs/UserServiceApi.md#setPassword) | **POST** /users/passwords/{{passwordResetID}} | 
*DrivewealthSdk.UserServiceApi* | [**signupLive**](docs/UserServiceApi.md#signupLive) | **POST** /signups/live | 
*DrivewealthSdk.UserServiceApi* | [**signupPractice**](docs/UserServiceApi.md#signupPractice) | **POST** /signups/practice | 
*DrivewealthSdk.WatchlistServiceApi* | [**get**](docs/WatchlistServiceApi.md#get) | **GET** /users/{{userId}}/settings/watchList | 
*DrivewealthSdk.WatchlistServiceApi* | [**save**](docs/WatchlistServiceApi.md#save) | **POST** /users/{{userId}}/settings | 


## Documentation for Models

 - [DrivewealthSdk.Account](docs/Account.md)
 - [DrivewealthSdk.Blotter](docs/Blotter.md)
 - [DrivewealthSdk.Cash](docs/Cash.md)
 - [DrivewealthSdk.Endpoints](docs/Endpoints.md)
 - [DrivewealthSdk.Environments](docs/Environments.md)
 - [DrivewealthSdk.Equity](docs/Equity.md)
 - [DrivewealthSdk.ErrorModel](docs/ErrorModel.md)
 - [DrivewealthSdk.FeatureToggle](docs/FeatureToggle.md)
 - [DrivewealthSdk.FeatureToggles](docs/FeatureToggles.md)
 - [DrivewealthSdk.Fundamental](docs/Fundamental.md)
 - [DrivewealthSdk.Instrument](docs/Instrument.md)
 - [DrivewealthSdk.Instruments](docs/Instruments.md)
 - [DrivewealthSdk.Orders](docs/Orders.md)
 - [DrivewealthSdk.Positions](docs/Positions.md)
 - [DrivewealthSdk.Settings](docs/Settings.md)
 - [DrivewealthSdk.Transactions](docs/Transactions.md)
 - [DrivewealthSdk.User](docs/User.md)
 - [DrivewealthSdk.Watchlist](docs/Watchlist.md)


## Documentation for Authorization

 All endpoints do not require authorization.

