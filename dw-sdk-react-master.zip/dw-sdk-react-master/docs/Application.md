# DrivewealthSdk.Application

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**marketState** | **Number** |  | [optional] 
**wlpid** | **String** |  | [optional] 
**quotesFailureThreshold** | **Number** |  | [optional] 
**quotesFailureTime** | **Number** |  | [optional] 
**accountRefreshRate** | **Number** |  | [optional] 
**maxOrderStatusAttempts** | **Number** |  | [optional] 
**starterFunds** | **Number** |  | [optional] 
**defaultLanguageID** | **String** |  | [optional] 
**serviceHost** | **String** |  | [optional] 


