# DrivewealthSdk.OrderServiceApi

All URIs are relative to *http://api.drivewealth.io/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cancel**](OrderServiceApi.md#cancel) | **DELETE** /orders/{{orderID}} | 
[**submitBasketOrders**](OrderServiceApi.md#submitBasketOrders) | **POST** /orders | 


<a name="cancel"></a>
# **cancel**
> Blotter cancel(orderID)



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.OrderServiceApi();

var orderID = "orderID_example"; // String | set of parameters to get chart data. ***NEEDS WORK***

apiInstance.cancel(orderID).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orderID** | **String**| set of parameters to get chart data. ***NEEDS WORK*** | 

### Return type

[**Blotter**](Blotter.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="submitBasketOrders"></a>
# **submitBasketOrders**
> Blotter submitBasketOrders(opts)



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.OrderServiceApi();

var opts = { 
  'data': null // Object | username for forgot password
};
apiInstance.submitBasketOrders(opts).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **data** | **Object**| username for forgot password | [optional] 

### Return type

[**Blotter**](Blotter.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

