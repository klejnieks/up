# DrivewealthSdk.Settings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**marketState** | **Number** |  | [optional] 
**wlpid** | **String** |  | [optional] 
**quotesRefreshRate** | **Number** |  | [optional] 
**quotesFailureThreshold** | **Number** |  | [optional] 
**quotesFailureTime** | **Number** |  | [optional] 
**accountRefreshRate** | **Number** |  | [optional] 
**maxOrderStatusAttempts** | **Number** |  | [optional] 
**starterFunds** | **Number** |  | [optional] 
**defaultLanguageID** | **String** |  | [optional] 
**serviceHost** | **String** |  | [optional] 


