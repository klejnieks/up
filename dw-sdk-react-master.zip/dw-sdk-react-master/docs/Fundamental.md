# DrivewealthSdk.Fundamental

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instrumentID** | **String** |  | [optional] 
**symbol** | **String** |  | [optional] 
**companyName** | **String** |  | [optional] 
**yesterdayClose** | **Number** |  | [optional] 
**openPrice** | **Number** |  | [optional] 
**bidPrice** | **Number** |  | [optional] 
**askPrice** | **Number** |  | [optional] 
**lowPrice** | **Number** |  | [optional] 
**highPrice** | **Number** |  | [optional] 
**fiftyTwoWeekLowPrice** | **Number** |  | [optional] 
**fiftyTwoWeekHighPrice** | **Number** |  | [optional] 
**cumulativeVolume** | **Number** |  | [optional] 
**thirtyDayAvgVolume** | **Number** |  | [optional] 
**marketCap** | **Number** |  | [optional] 
**peRatio** | **Number** |  | [optional] 
**dividendYield** | **Number** |  | [optional] 
**earningsPerShare** | **Number** |  | [optional] 
**dividend** | **Number** |  | [optional] 


