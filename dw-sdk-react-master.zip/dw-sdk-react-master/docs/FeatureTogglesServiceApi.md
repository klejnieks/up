# DrivewealthSdk.FeatureTogglesServiceApi

All URIs are relative to *http://api.drivewealth.io/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getFeatureToggles**](FeatureTogglesServiceApi.md#getFeatureToggles) | **GET** /featureToggles | 


<a name="getFeatureToggles"></a>
# **getFeatureToggles**
> FeatureToggles getFeatureToggles()



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.FeatureTogglesServiceApi();
apiInstance.getFeatureToggles().then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters
This endpoint does not need any parameter.

### Return type

[**FeatureToggles**](FeatureToggles.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

