# DrivewealthSdk.Blotter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountID** | **String** |  | [optional] 
**accountNo** | **String** |  | [optional] 
**cash** | **Object** |  | [optional] 


