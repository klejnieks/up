# DrivewealthSdk.Watchlist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userID** | **String** |  | [optional] 
**key** | **String** |  | [optional] 
**value** | **String** |  | [optional] 


