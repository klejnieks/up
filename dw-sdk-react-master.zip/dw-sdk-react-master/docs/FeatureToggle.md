# DrivewealthSdk.FeatureToggle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**featureToggleID** | **String** |  | [optional] 
**enabled** | **Boolean** |  | [optional] 


