'use strict';

/**
* @module ApiClient
* @version 1.4.114
*
*
* Manages low level client-server communications, parameter marshalling, etc. There should not be any need for an
* application to use this class directly - the *Api and model classes provide the public API for the service. The
* contents of this file should be regarded as internal but are documented for completeness.
* @alias module:ApiClient
* @class
*/
class ApiClient {

    constructor() {
        /**
        * The base URL against which to resolve every API call's (relative) path.
        * @type {String}
        * @default http://api.drivewealth.io/v1
        */
        this.basePath = 'http://api.drivewealth.io/v1'.replace(/\/+$/, '');

        /**
        * The authentication methods to be included for all API calls.
        * @type {Array.<String>}
        */
        
        this.authentications = {
        };

        /**
        * The default HTTP headers to be included for all API calls.
        * @type {Array.<String>}
        * @default {}
        */
        this.defaultHeaders = {};

        /**
        * The default HTTP timeout for all API calls.
        * @type {Number}
        * @default 60000
        */
        this.timeout = 60000;
    };

    /**
    * Returns a string representation for an actual parameter.
    * @param param The actual parameter.
    * @returns {String} The string representation of <code>param</code>.
    */
    paramToString = (param) => {
        if (param == undefined || param == null) {
            return '';
        }
        if (param instanceof Date) {
            return param.toJSON();
        }
        return param.toString();
    };

    /**
    * Builds full URL by appending the given path to the base URL and replacing path parameter place-holders with parameter values.
    * NOTE: query parameters are not handled here.
    * @param {String} path The path to append to the base URL.
    * @param {Object} pathParams The parameter values to append.
    * @returns {String} The encoded path with parameter values substituted.
    */
    buildUrl = (path, pathParams) => {
        if (!path.match(/^\//)) {
            path = '/' + path;
        }
        var url = this.basePath + path;
        var _this = this;
        url = url.replace(/\{([\w-]+)\}/g, function(fullMatch, key) {
            var value;
            if (pathParams.hasOwnProperty(key)) {
                value = _this.paramToString(pathParams[key]);
            }
            else {
                value = fullMatch;
            }
            return encodeURIComponent(value);
        });
        return url;
    };

    /**
    * Checks whether the given content type represents JSON.<br>
    * JSON content type examples:<br>
    * <ul>
    * <li>application/json</li>
    * <li>application/json; charset=UTF8</li>
    * <li>APPLICATION/JSON</li>
    * </ul>
    * @param {String} contentType The MIME content type to check.
    * @returns {Boolean} <code>true</code> if <code>contentType</code> represents JSON, otherwise <code>false</code>.
    */
    isJsonMime = (contentType) => {
        return Boolean(contentType != null && contentType.match(/^application\/json(;.*)?$/i));
    };

    /**
    * Chooses a content type from the given array, with JSON preferred; i.e. return JSON if included, otherwise return the first.
    * @param {Array.<String>} contentTypes
    * @returns {String} The chosen content type, preferring JSON.
    */
    jsonPreferredMime = (contentTypes) => {
        for (var i = 0; i < contentTypes.length; i++) {
            if (this.isJsonMime(contentTypes[i])) {
                return contentTypes[i];
            }
        }
        return contentTypes[0];
    };

    /**
    * Checks whether the given parameter value represents file-like content.
    * @param param The parameter to check.
    * @returns {Boolean} <code>true</code> if <code>param</code> represents a file.
    */
    isFileParam = (param) => {
        // fs.ReadStream in Node.js (but not in runtime like browserify)
        if (typeof window === 'undefined' && typeof require === 'function' && require('fs') && param instanceof require('fs').ReadStream) {
            return true;
        }
        // Buffer in Node.js
        if (typeof Buffer === 'function' && param instanceof Buffer) {
            return true;
        }
        // Blob in browser
        if (typeof Blob === 'function' && param instanceof Blob) {
            return true;
        }
        // File in browser (it seems File object is also instance of Blob, but keep this for safe)
        if (typeof File === 'function' && param instanceof File) {
            return true;
        }
        return false;
    };

    /**
    * Normalizes parameter values:
    * <ul>
    * <li>remove nils</li>
    * <li>keep files and arrays</li>
    * <li>format to string with `paramToString` for other cases</li>
    * </ul>
    * @param {Object.<String, Object>} params The parameters as object properties.
    * @returns {Object.<String, Object>} normalized parameters.
    */
    normalizeParams = (params) => {
        var newParams = {};
        for (var key in params) {
            if (params.hasOwnProperty(key) && params[key] != undefined && params[key] != null) {
                var value = params[key];
                if (this.isFileParam(value) || Array.isArray(value)) {
                    newParams[key] = value;
                } else {
                    newParams[key] = this.paramToString(value);
                }
            }
        }
        return newParams;
    };

    /**
    * Applies authentication headers to the request.
    * @param {Object} request The request object created by a <code>superagent()</code> call.
    * @param {Array.<String>} authNames An array of authentication method names.
    */
    applyAuthToRequest = (request, authNames) => {
        var _this = this;
        authNames.forEach(function(authName) {
            var auth = _this.authentications[authName];
            switch (auth.type) {
                case 'basic':
                if (auth.username || auth.password) {
                    request.auth(auth.username || '', auth.password || '');
                }
                break;
                case 'apiKey':
                if (auth.apiKey) {
                    var data = {};
                    if (auth.apiKeyPrefix) {
                        data[auth.name] = auth.apiKeyPrefix + ' ' + auth.apiKey;
                    } else {
                        data[auth.name] = auth.apiKey;
                    }
                    if (auth['in'] === 'header') {
                        request.set(data);
                    } else {
                        request.query(data);
                    }
                }
                break;
                case 'oauth2':
                if (auth.accessToken) {
                    request.set({'Authorization': 'Bearer ' + auth.accessToken});
                }
                break;
                default:
                throw new Error('Unknown authentication type: ' + auth.type);
            }
        });
    };

    /**
    * Deserializes an HTTP response body into a value of the specified type.
    * @param {Object} response A SuperAgent response object.
    * @param {(String|Array.<String>|Object.<String, Object>|Function)} returnType The type to return. Pass a string for simple types
    * or the constructor function for a complex type. Pass an array containing the type name to return an array of that type. To
    * return an object, pass an object with one property whose name is the key type and whose value is the corresponding value type:
    * all properties on <code>data<code> will be converted to this type.
    * @returns A value of the specified type.
    */
    deserialize = (response, returnType) => {
        if (response == null || returnType == null) {
            return null;
        }
        // Rely on SuperAgent for parsing response body.
        // See http://visionmedia.github.io/superagent/#parsing-response-bodies
        var data = response.body;
        if (data == null) {
            // SuperAgent does not always produce a body; use the unparsed response as a fallback
            data = response.text;
        }
        return exports.convertToType(data, returnType);
    };

        /**
    * Invokes the REST service using the supplied settings and parameters.
    * @param {String} path The base URL to invoke.
    * @param {String} httpMethod The HTTP method to use.
    * @param {Object.<String, String>} pathParams A map of path parameters and their values.
    * @param {Object.<String, Object>} queryParams A map of query parameters and their values.
    * @param {Object.<String, Object>} headerParams A map of header parameters and their values.
    * @param {Object.<String, Object>} formParams A map of form parameters and their values.
    * @param {Object} bodyParam The value to pass as the request body.
    * @param {Array.<String>} authNames An array of authentication type names.
    * @param {Array.<String>} contentTypes An array of request MIME types.
    * @param {Array.<String>} accepts An array of acceptable response MIME types.
    * @param {(String|Array|ObjectFunction)} returnType The required type to return; can be a string for simple types or the
    * constructor for a complex type.    * @returns {Promise} A Promise object.
    */
    callApi = (path, httpMethod, pathParams, queryParams, headerParams, formParams, bodyParam, authNames, contentTypes, accepts, returnType) => {
        var _this = this;
        var url = this.buildUrl(path, pathParams);
        var request = superagent(httpMethod, url);

        // apply authentications
        this.applyAuthToRequest(request, authNames);

        // set query parameters
        request.query(this.normalizeParams(queryParams));

        // set header parameters
        request.set(this.defaultHeaders).set(this.normalizeParams(headerParams));

        // set request timeout
        request.timeout(this.timeout);

        var contentType = this.jsonPreferredMime(contentTypes);
        if (contentType) {
            request.type(contentType);
        } else if (!request.header['Content-Type']) {
            request.type('application/json');
        }

        if (contentType === 'application/x-www-form-urlencoded') {
            request.send(this.normalizeParams(formParams));
        } else if (contentType == 'multipart/form-data') {
            var _formParams = this.normalizeParams(formParams);
            for (var key in _formParams) {
                if (_formParams.hasOwnProperty(key)) {
                    if (this.isFileParam(_formParams[key])) {
                        // file field
                        request.attach(key, _formParams[key]);
                    } else {
                        request.field(key, _formParams[key]);
                    }
                }
            }
        } else if (bodyParam) {
            request.send(bodyParam);
        }

        var accept = this.jsonPreferredMime(accepts);
        if (accept) {
            request.accept(accept);
        }

        return new Promise(function(resolve, reject) {
            request.end(function(error, response) {
                if (error) {
                    reject(error);
                } else {
                    var data = _this.deserialize(response, returnType);
                    resolve(data);
                }
            });
        });
    };

    /**
    * Parses an ISO-8601 string representation of a date value.
    * @param {String} str The date value as a string.
    * @returns {Date} The parsed date object.
    */
    parseDate = (str) => {
        return new Date(str.replace(/T/i, ' '));
    };

    /**
    * Converts a value to the specified type.
    * @param {(String|Object)} data The data to convert, as a string or object.
    * @param {(String|Array.<String>|Object.<String, Object>|Function)} type The type to return. Pass a string for simple types
    * or the constructor function for a complex type. Pass an array containing the type name to return an array of that type. To
    * return an object, pass an object with one property whose name is the key type and whose value is the corresponding value type:
    * all properties on <code>data<code> will be converted to this type.
    * @returns An instance of the specified type.
    */
    convertToType = (data, type) => {
        switch (type) {
            case 'Boolean':
            return Boolean(data);
            case 'Integer':
            return parseInt(data, 10);
            case 'Number':
            return parseFloat(data);
            case 'String':
            return String(data);
            case 'Date':
            return this.parseDate(String(data));
            default:
            if (type === Object) {
                // generic object, return directly
                return data;
            } else if (typeof type === 'function') {
                // for model type like: User
                return type.constructFromObject(data);
            } else if (Array.isArray(type)) {
                // for array type like: ['String']
                var itemType = type[0];
                return data.map(function(item) {
                    return exports.convertToType(item, itemType);
                });
            } else if (typeof type === 'object') {
                // for plain object type like: {'String': 'Integer'}
                var keyType, valueType;
                for (var k in type) {
                    if (type.hasOwnProperty(k)) {
                        keyType = k;
                        valueType = type[k];
                        break;
                    }
                }
                var result = {};
                for (var k in data) {
                    if (data.hasOwnProperty(k)) {
                        var key = exports.convertToType(k, keyType);
                        var value = exports.convertToType(data[k], valueType);
                        result[key] = value;
                    }
                }
                return result;
            } else {
                // for unknown type, return the data directly
                return data;
            }
        }
    };

    /**
    * Constructs a new map or array model from REST data.
    * @param data {Object|Array} The REST data.
    * @param obj {Object|Array} The target object or array.
    */
    constructFromObject = (data, obj, itemType) => {
        if (Array.isArray(data)) {
            for (var i = 0; i < data.length; i++) {
                if (data.hasOwnProperty(i))
                obj[i] = exports.convertToType(data[i], itemType);
            }
        } else {
            for (var k in data) {
                if (data.hasOwnProperty(k))
                result[k] = exports.convertToType(data[k], itemType);
            }
        }
    };

};

module.exports = new ApiClient();
