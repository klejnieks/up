'use strict';

/**
* UserService service.
* @module api/UserServiceApi
* @version 1.4.114
*/

/**
* Constructs a new UserServiceApi. 
* @alias module:api/UserServiceApi
* @class
* @param {module:ApiClient} apiClient Optional API client implementation to use,
* default to {@link module:ApiClient#instance} if unspecified.
*/
class UserServiceApi {

    

    /**
    * Returns the account blotter for a given user and account id
    * @param {String} userID ID of user to fetch
    * @param {Object} opts Optional parameters
    * @param {Object} data username for forgot password
    */
    edit = (url:String, headers:Object, data:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/users/" + userID + "", {
    			method: 'PUT',
    			headers: headers,
                body: JSON.stringify(data)
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns a user based on a single ID
    * @param {String} userID ID of user to fetch
    * @param {Object} opts Optional parameters
    * @param {Object} data username for forgot password
    * data is of type: {module:model/User}
    */
    forgotPassword = (url:String, headers:Object, data:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/users/passwords" + username + "", {
    			method: 'POST',
    			headers: headers,
                body: JSON.stringify(data)
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns the account blotter for a given user and account id
    * @param {String} userID ID of user to fetch
    * @param {String} key ID of user to fetch
    * data is of type: {module:model/Blotter}
    */
    getSetting = (url:String, headers:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/users/" + userID + "/settings/" + key + "", {
    			method: 'GET',
    			headers: headers
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns the account blotter for a given user and account id
    * @param {String} userID ID of user to fetch
    * data is of type: {module:model/User}
    */
    getStatus = (url:String, headers:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/users/" + userID + "/status", {
    			method: 'GET',
    			headers: headers
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns a user based on a single ID
    * @param {String} sessionKey session key of the user
    * data is of type: {module:model/User}
    */
    getUser = (url:String, headers:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/userSessions/" + sessionKey + "", {
    			method: 'GET',
    			headers: headers
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns a user based on a single ID
    * @param {String} id ID of user to fetch
    * data is of type: {module:model/User}
    */
    getUserByUserID = (url:String, headers:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/users/" + id + "", {
    			method: 'GET',
    			headers: headers
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns the account blotter for a given user and account id
    * @param {String} sessionKey ID of user to fetch
    */
    heartbeat = (url:String, headers:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/userSessions/" + sessionKey + "?action=heartbeat", {
    			method: 'PUT',
    			headers: headers
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns the account blotter for a given user and account id
    * @param {String} username ID of user to fetch
    * data is of type: {module:model/User}
    */
    isUsernameAvailable = (url:String, headers:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/users?username=" + username + "", {
    			method: 'GET',
    			headers: headers
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * User Login
    * @param {Object} opts Optional parameters
    * @param {Object} data username for forgot password
    * data is of type: {module:model/User}
    */
    login = (url:String, headers:Object, data:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/userSessions", {
    			method: 'POST',
    			headers: headers,
                body: JSON.stringify(data)
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns a user based on a single ID
    * @param {String} code username for forgot password
    * @param {Object} data username for forgot password
    * data is of type: {module:model/User}
    */
    resetPassword = (url:String, headers:Object, data:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/users/passwords/" + code + "", {
    			method: 'PUT',
    			headers: headers,
                body: JSON.stringify(data)
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns a user based on a single ID
    * @param {String} userID ID of user to fetch
    * @param {Object} opts Optional parameters
    * @param {Object} data username for forgot password
    * data is of type: {module:model/User}
    */
    saveSetting = (url:String, headers:Object, data:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/users/" + userID + "/settings", {
    			method: 'POST',
    			headers: headers,
                body: JSON.stringify(data)
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns a user based on a single ID
    * @param {String} passwordResetID username for forgot password
    * @param {Object} opts Optional parameters
    * @param {Object} data username for forgot password
    * data is of type: {module:model/User}
    */
    setPassword = (url:String, headers:Object, data:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/users/passwords/" + passwordResetID + "", {
    			method: 'POST',
    			headers: headers,
                body: JSON.stringify(data)
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns a user based on a single ID
    * @param {Object} opts Optional parameters
    * @param {Object} data User signup data object
    * data is of type: {module:model/User}
    */
    signupLive = (url:String, headers:Object, data:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/signups/live", {
    			method: 'POST',
    			headers: headers,
                body: JSON.stringify(data)
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns a user based on a single ID
    * @param {Object} opts Optional parameters
    * @param {Object} data username for forgot password
    * data is of type: {module:model/User}
    */
    signupPractice = (url:String, headers:Object, data:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/signups/practice", {
    			method: 'POST',
    			headers: headers,
                body: JSON.stringify(data)
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

};

module.exports = UserServiceApi;

