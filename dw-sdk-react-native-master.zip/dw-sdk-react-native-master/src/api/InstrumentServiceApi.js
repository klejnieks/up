'use strict';

/**
* InstrumentService service.
* @module api/InstrumentServiceApi
* @version 1.4.114
*/

/**
* Constructs a new InstrumentServiceApi. 
* @alias module:api/InstrumentServiceApi
* @class
* @param {module:ApiClient} apiClient Optional API client implementation to use,
* default to {@link module:ApiClient#instance} if unspecified.
*/
class InstrumentServiceApi {

    

    /**
    * Returns the account blotter for a given user and account id
    * @param {String} params set of parameters to get chart data. ***NEEDS WORK***
    * data is of type: {module:model/Blotter}
    */
    getBarsData = (url:String, headers:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/bars?instrumentID=" + params + "", {
    			method: 'GET',
    			headers: headers
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns details on a specific instrument.
    * @param {String} instrumentID ID of Instrument to fetch
    * data is of type: {module:model/Instrument}
    */
    getInstrumentByID = (url:String, headers:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/instruments/" + instrumentID + "?options=F", {
    			method: 'GET',
    			headers: headers
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns the account blotter for a given user and account id
    * @param {String} symbols Array of symbols of Instrument to fetch
    * data is of type: {module:model/Instruments}
    */
    getInstrumentBySymbols = (url:String, headers:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/instruments/?symbols=" + symbols + "", {
    			method: 'GET',
    			headers: headers
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns the account blotter for a given user and account id
    * @param {String} params ID of user to fetch
    * data is of type: {module:model/Instruments}
    */
    getInstruments = (url:String, headers:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/instruments?" + params + "", {
    			method: 'GET',
    			headers: headers
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

};

module.exports = InstrumentServiceApi;

