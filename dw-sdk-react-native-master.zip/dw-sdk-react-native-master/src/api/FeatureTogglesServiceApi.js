'use strict';

/**
* FeatureTogglesService service.
* @module api/FeatureTogglesServiceApi
* @version 1.4.114
*/

/**
* Constructs a new FeatureTogglesServiceApi. 
* @alias module:api/FeatureTogglesServiceApi
* @class
* @param {module:ApiClient} apiClient Optional API client implementation to use,
* default to {@link module:ApiClient#instance} if unspecified.
*/
class FeatureTogglesServiceApi {

    

    /**
    * Returns the account blotter for a given user and account id
    * data is of type: {module:model/FeatureToggles}
    */
    getFeatureToggles = (url:String, headers:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/featureToggles", {
    			method: 'GET',
    			headers: headers
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

};

module.exports = FeatureTogglesServiceApi;

