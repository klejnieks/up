'use strict';

/**
* AccountsService service.
* @module api/AccountsServiceApi
* @version 1.4.114
*/

/**
* Constructs a new AccountsServiceApi. 
* @alias module:api/AccountsServiceApi
* @class
* @param {module:ApiClient} apiClient Optional API client implementation to use,
* default to {@link module:ApiClient#instance} if unspecified.
*/
class AccountsServiceApi {

    

    /**
    * Returns the account blotter for a given user and account id
    * @param {String} userID ID of user to fetch
    * @param {String} accountID ID of user to fetch
    * data is of type: {module:model/User}
    */
    getAccountByID = (url:String, headers:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/users/" + userID + "/accounts/" + accountID + "", {
    			method: 'GET',
    			headers: headers
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns the account blotter for a given user and account id
    * @param {String} userID ID of user to fetch
    * data is of type: {module:model/User}
    */
    getAccounts = (url:String, headers:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/users/" + userID + "/accounts", {
    			method: 'GET',
    			headers: headers
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns the account blotter for a given user and account id
    * @param {String} userID ID of user to fetch
    * @param {String} accountID ID of user to fetch
    * data is of type: {module:model/User}
    */
    getSummary = (url:String, headers:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/users/" + userID + "/accountSummary/" + accountID + "", {
    			method: 'GET',
    			headers: headers
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

};

module.exports = AccountsServiceApi;

