'use strict';

/**
* OrderService service.
* @module api/OrderServiceApi
* @version 1.4.114
*/

/**
* Constructs a new OrderServiceApi. 
* @alias module:api/OrderServiceApi
* @class
* @param {module:ApiClient} apiClient Optional API client implementation to use,
* default to {@link module:ApiClient#instance} if unspecified.
*/
class OrderServiceApi {

    

    /**
    * Returns the account blotter for a given user and account id
    * @param {String} orderID set of parameters to get chart data. ***NEEDS WORK***
    * data is of type: {module:model/Blotter}
    */
    cancel = (url:String, headers:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/orders/" + orderID + "", {
    			method: 'DELETE',
    			headers: headers
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

    /**
    * Returns the account blotter for a given user and account id
    * @param {Object} opts Optional parameters
    * @param {Object} data username for forgot password
    * data is of type: {module:model/Blotter}
    */
    submitBasketOrders = (url:String, headers:Object, data:Object):Promise => {
        return new Promise((resolve, reject) => {
            fetch(url + "/orders", {
    			method: 'POST',
    			headers: headers,
                body: JSON.stringify(data)
    		})
            .then(response => {
                if(response.ok) {
                    response.json().then(json => resolve(json));
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => { reject(err) });
        });
    };

    

};

module.exports = OrderServiceApi;

