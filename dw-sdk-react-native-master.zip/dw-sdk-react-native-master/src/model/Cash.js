'use strict';



/**
* The Cash model module.
* @module model/Cash
* @version 1.4.114
**/

/**
* Constructs a new <code>Cash</code>.
* @alias module:model/Cash
* @class
*/


var _cashAvailableForTrade:String = undefined, _cashAvailableForWithdrawal:String = undefined, _cashBalance:String = undefined, _cashBalance:String

class Cash {

    constructor() {
        //
    }

    /**
    * 
    * @member {String} cashAvailableForTrade
    */

    get cashAvailableForTrade():String { return _cashAvailableForTrade; }
    set cashAvailableForTrade(value:String):void {
        _cashAvailableForTrade = value;
    }
    /**
    * 
    * @member {String} cashAvailableForWithdrawal
    */

    get cashAvailableForWithdrawal():String { return _cashAvailableForWithdrawal; }
    set cashAvailableForWithdrawal(value:String):void {
        _cashAvailableForWithdrawal = value;
    }
    /**
    * 
    * @member {String} cashBalance
    */

    get cashBalance():String { return _cashBalance; }
    set cashBalance(value:String):void {
        _cashBalance = value;
    }

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        _cashAvailableForTrade = undefined;
        _cashAvailableForWithdrawal = undefined;
        _cashBalance = undefined;
    }

    toString() {
        return JSON.stringify({
            cashAvailableForTrade: _cashAvailableForTrade,cashAvailableForWithdrawal: _cashAvailableForWithdrawal,cashBalance: _cashBalance, 
        });
    }

};

module.exports = new Cash();




