'use strict';



/**
* The Positions model module.
* @module model/Positions
* @version 1.4.114
**/

/**
* Constructs a new <code>Positions</code>.
* @alias module:model/Positions
* @class
*/


var _symbol:String = undefined, _instrumentID:String = undefined, _openQty:String = undefined, _costBasis:String = undefined, _marketValue:String = undefined, _side:String = undefined, _priorClose:String = undefined, _availableForTradingQty:String = undefined, _avgPrice:String = undefined, _mktPrice:String = undefined, _unrealizedPL:String = undefined, _unrealizedDayPLPercent:String = undefined, _unrealizedDayPL:String = undefined, _unrealizedDayPL:String

class Positions {

    constructor() {
        //
    }

    /**
    * 
    * @member {String} symbol
    */

    get symbol():String { return _symbol; }
    set symbol(value:String):void {
        _symbol = value;
    }
    /**
    * 
    * @member {String} instrumentID
    */

    get instrumentID():String { return _instrumentID; }
    set instrumentID(value:String):void {
        _instrumentID = value;
    }
    /**
    * 
    * @member {String} openQty
    */

    get openQty():String { return _openQty; }
    set openQty(value:String):void {
        _openQty = value;
    }
    /**
    * 
    * @member {String} costBasis
    */

    get costBasis():String { return _costBasis; }
    set costBasis(value:String):void {
        _costBasis = value;
    }
    /**
    * 
    * @member {String} marketValue
    */

    get marketValue():String { return _marketValue; }
    set marketValue(value:String):void {
        _marketValue = value;
    }
    /**
    * 
    * @member {String} side
    */

    get side():String { return _side; }
    set side(value:String):void {
        _side = value;
    }
    /**
    * 
    * @member {String} priorClose
    */

    get priorClose():String { return _priorClose; }
    set priorClose(value:String):void {
        _priorClose = value;
    }
    /**
    * 
    * @member {String} availableForTradingQty
    */

    get availableForTradingQty():String { return _availableForTradingQty; }
    set availableForTradingQty(value:String):void {
        _availableForTradingQty = value;
    }
    /**
    * 
    * @member {String} avgPrice
    */

    get avgPrice():String { return _avgPrice; }
    set avgPrice(value:String):void {
        _avgPrice = value;
    }
    /**
    * 
    * @member {String} mktPrice
    */

    get mktPrice():String { return _mktPrice; }
    set mktPrice(value:String):void {
        _mktPrice = value;
    }
    /**
    * 
    * @member {String} unrealizedPL
    */

    get unrealizedPL():String { return _unrealizedPL; }
    set unrealizedPL(value:String):void {
        _unrealizedPL = value;
    }
    /**
    * 
    * @member {String} unrealizedDayPLPercent
    */

    get unrealizedDayPLPercent():String { return _unrealizedDayPLPercent; }
    set unrealizedDayPLPercent(value:String):void {
        _unrealizedDayPLPercent = value;
    }
    /**
    * 
    * @member {String} unrealizedDayPL
    */

    get unrealizedDayPL():String { return _unrealizedDayPL; }
    set unrealizedDayPL(value:String):void {
        _unrealizedDayPL = value;
    }

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        _symbol = undefined;
        _instrumentID = undefined;
        _openQty = undefined;
        _costBasis = undefined;
        _marketValue = undefined;
        _side = undefined;
        _priorClose = undefined;
        _availableForTradingQty = undefined;
        _avgPrice = undefined;
        _mktPrice = undefined;
        _unrealizedPL = undefined;
        _unrealizedDayPLPercent = undefined;
        _unrealizedDayPL = undefined;
    }

    toString() {
        return JSON.stringify({
            symbol: _symbol,instrumentID: _instrumentID,openQty: _openQty,costBasis: _costBasis,marketValue: _marketValue,side: _side,priorClose: _priorClose,availableForTradingQty: _availableForTradingQty,avgPrice: _avgPrice,mktPrice: _mktPrice,unrealizedPL: _unrealizedPL,unrealizedDayPLPercent: _unrealizedDayPLPercent,unrealizedDayPL: _unrealizedDayPL, 
        });
    }

};

module.exports = new Positions();




