'use strict';



/**
* The Instrument model module.
* @module model/Instrument
* @version 1.4.114
**/

/**
* Constructs a new <code>Instrument</code>.
* @alias module:model/Instrument
* @class
*/


var _instrumentID:String = undefined, _name3:String = undefined, _name:String = undefined, _currencyID:String = undefined, _description:String = undefined, _exchangeID:String = undefined, _limitStatus:Number = undefined, _instrumentTypeID:Number = undefined, _isLongOnly:Boolean = undefined, _marginCurrencyID:String = undefined, _orderSizeMax:Number = undefined, _orderSizeMin:Number = undefined, _orderSizeStep:Number = undefined, _rateAsk:Number = undefined, _rateBid:Number = undefined, _ratePrecision:Number = undefined, _symbol:String = undefined, _tradeStatus:Number = undefined, _tradingHours:String = undefined, _uom:String = undefined, _urlImage:String = undefined, _urlInvestor:String = undefined, _sector:String = undefined, _priorClose:Number = undefined, _nameLower:String = undefined, _underlyingID:String = undefined, _marketState:Number = undefined, _minTic:Number = undefined, _pipMultiplier:Number = undefined, _tickerSymbol:String = undefined, _rebateSpread:Number = undefined, _longOnly:Boolean = undefined, _fundamentalDataModel:Fundamental = undefined, _fundamentalDataModel:Fundamental

class Instrument {

    constructor() {
        //
    }

    /**
    * 
    * @member {String} instrumentID
    */

    get instrumentID():String { return _instrumentID; }
    set instrumentID(value:String):void {
        _instrumentID = value;
    }
    /**
    * 
    * @member {String} name3
    */

    get name3():String { return _name3; }
    set name3(value:String):void {
        _name3 = value;
    }
    /**
    * 
    * @member {String} name
    */

    get name():String { return _name; }
    set name(value:String):void {
        _name = value;
    }
    /**
    * 
    * @member {String} currencyID
    */

    get currencyID():String { return _currencyID; }
    set currencyID(value:String):void {
        _currencyID = value;
    }
    /**
    * 
    * @member {String} description
    */

    get description():String { return _description; }
    set description(value:String):void {
        _description = value;
    }
    /**
    * 
    * @member {String} exchangeID
    */

    get exchangeID():String { return _exchangeID; }
    set exchangeID(value:String):void {
        _exchangeID = value;
    }
    /**
    * 
    * @member {Number} limitStatus
    */

    get limitStatus():Number { return _limitStatus; }
    set limitStatus(value:Number):void {
        _limitStatus = value;
    }
    /**
    * 
    * @member {Number} instrumentTypeID
    */

    get instrumentTypeID():Number { return _instrumentTypeID; }
    set instrumentTypeID(value:Number):void {
        _instrumentTypeID = value;
    }
    /**
    * 
    * @member {Boolean} isLongOnly
    */

    get isLongOnly():Boolean { return _isLongOnly; }
    set isLongOnly(value:Boolean):void {
        _isLongOnly = value;
    }
    /**
    * 
    * @member {String} marginCurrencyID
    */

    get marginCurrencyID():String { return _marginCurrencyID; }
    set marginCurrencyID(value:String):void {
        _marginCurrencyID = value;
    }
    /**
    * 
    * @member {Number} orderSizeMax
    */

    get orderSizeMax():Number { return _orderSizeMax; }
    set orderSizeMax(value:Number):void {
        _orderSizeMax = value;
    }
    /**
    * 
    * @member {Number} orderSizeMin
    */

    get orderSizeMin():Number { return _orderSizeMin; }
    set orderSizeMin(value:Number):void {
        _orderSizeMin = value;
    }
    /**
    * 
    * @member {Number} orderSizeStep
    */

    get orderSizeStep():Number { return _orderSizeStep; }
    set orderSizeStep(value:Number):void {
        _orderSizeStep = value;
    }
    /**
    * 
    * @member {Number} rateAsk
    */

    get rateAsk():Number { return _rateAsk; }
    set rateAsk(value:Number):void {
        _rateAsk = value;
    }
    /**
    * 
    * @member {Number} rateBid
    */

    get rateBid():Number { return _rateBid; }
    set rateBid(value:Number):void {
        _rateBid = value;
    }
    /**
    * 
    * @member {Number} ratePrecision
    */

    get ratePrecision():Number { return _ratePrecision; }
    set ratePrecision(value:Number):void {
        _ratePrecision = value;
    }
    /**
    * 
    * @member {String} symbol
    */

    get symbol():String { return _symbol; }
    set symbol(value:String):void {
        _symbol = value;
    }
    /**
    * 
    * @member {Number} tradeStatus
    */

    get tradeStatus():Number { return _tradeStatus; }
    set tradeStatus(value:Number):void {
        _tradeStatus = value;
    }
    /**
    * 
    * @member {String} tradingHours
    */

    get tradingHours():String { return _tradingHours; }
    set tradingHours(value:String):void {
        _tradingHours = value;
    }
    /**
    * 
    * @member {String} uom
    */

    get uom():String { return _uom; }
    set uom(value:String):void {
        _uom = value;
    }
    /**
    * 
    * @member {String} urlImage
    */

    get urlImage():String { return _urlImage; }
    set urlImage(value:String):void {
        _urlImage = value;
    }
    /**
    * 
    * @member {String} urlInvestor
    */

    get urlInvestor():String { return _urlInvestor; }
    set urlInvestor(value:String):void {
        _urlInvestor = value;
    }
    /**
    * 
    * @member {String} sector
    */

    get sector():String { return _sector; }
    set sector(value:String):void {
        _sector = value;
    }
    /**
    * 
    * @member {Number} priorClose
    */

    get priorClose():Number { return _priorClose; }
    set priorClose(value:Number):void {
        _priorClose = value;
    }
    /**
    * 
    * @member {String} nameLower
    */

    get nameLower():String { return _nameLower; }
    set nameLower(value:String):void {
        _nameLower = value;
    }
    /**
    * 
    * @member {String} underlyingID
    */

    get underlyingID():String { return _underlyingID; }
    set underlyingID(value:String):void {
        _underlyingID = value;
    }
    /**
    * 
    * @member {Number} marketState
    */

    get marketState():Number { return _marketState; }
    set marketState(value:Number):void {
        _marketState = value;
    }
    /**
    * 
    * @member {Number} minTic
    */

    get minTic():Number { return _minTic; }
    set minTic(value:Number):void {
        _minTic = value;
    }
    /**
    * 
    * @member {Number} pipMultiplier
    */

    get pipMultiplier():Number { return _pipMultiplier; }
    set pipMultiplier(value:Number):void {
        _pipMultiplier = value;
    }
    /**
    * 
    * @member {String} tickerSymbol
    */

    get tickerSymbol():String { return _tickerSymbol; }
    set tickerSymbol(value:String):void {
        _tickerSymbol = value;
    }
    /**
    * 
    * @member {Number} rebateSpread
    */

    get rebateSpread():Number { return _rebateSpread; }
    set rebateSpread(value:Number):void {
        _rebateSpread = value;
    }
    /**
    * 
    * @member {Boolean} longOnly
    */

    get longOnly():Boolean { return _longOnly; }
    set longOnly(value:Boolean):void {
        _longOnly = value;
    }
    /**
    * 
    * @member {module:model/Fundamental} fundamentalDataModel
    */

    get fundamentalDataModel():Fundamental { return _fundamentalDataModel; }
    set fundamentalDataModel(value:Fundamental):void {
        _fundamentalDataModel = value;
    }

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        _instrumentID = undefined;
        _name3 = undefined;
        _name = undefined;
        _currencyID = undefined;
        _description = undefined;
        _exchangeID = undefined;
        _limitStatus = undefined;
        _instrumentTypeID = undefined;
        _isLongOnly = undefined;
        _marginCurrencyID = undefined;
        _orderSizeMax = undefined;
        _orderSizeMin = undefined;
        _orderSizeStep = undefined;
        _rateAsk = undefined;
        _rateBid = undefined;
        _ratePrecision = undefined;
        _symbol = undefined;
        _tradeStatus = undefined;
        _tradingHours = undefined;
        _uom = undefined;
        _urlImage = undefined;
        _urlInvestor = undefined;
        _sector = undefined;
        _priorClose = undefined;
        _nameLower = undefined;
        _underlyingID = undefined;
        _marketState = undefined;
        _minTic = undefined;
        _pipMultiplier = undefined;
        _tickerSymbol = undefined;
        _rebateSpread = undefined;
        _longOnly = undefined;
        _fundamentalDataModel = undefined;
    }

    toString() {
        return JSON.stringify({
            instrumentID: _instrumentID,name3: _name3,name: _name,currencyID: _currencyID,description: _description,exchangeID: _exchangeID,limitStatus: _limitStatus,instrumentTypeID: _instrumentTypeID,isLongOnly: _isLongOnly,marginCurrencyID: _marginCurrencyID,orderSizeMax: _orderSizeMax,orderSizeMin: _orderSizeMin,orderSizeStep: _orderSizeStep,rateAsk: _rateAsk,rateBid: _rateBid,ratePrecision: _ratePrecision,symbol: _symbol,tradeStatus: _tradeStatus,tradingHours: _tradingHours,uom: _uom,urlImage: _urlImage,urlInvestor: _urlInvestor,sector: _sector,priorClose: _priorClose,nameLower: _nameLower,underlyingID: _underlyingID,marketState: _marketState,minTic: _minTic,pipMultiplier: _pipMultiplier,tickerSymbol: _tickerSymbol,rebateSpread: _rebateSpread,longOnly: _longOnly,fundamentalDataModel: _fundamentalDataModel, 
        });
    }

};

module.exports = new Instrument();




