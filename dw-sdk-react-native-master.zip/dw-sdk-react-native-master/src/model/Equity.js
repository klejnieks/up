'use strict';



/**
* The Equity model module.
* @module model/Equity
* @version 1.4.114
**/

/**
* Constructs a new <code>Equity</code>.
* @alias module:model/Equity
* @class
*/


var _equityValue:String = undefined, _cash:Object = undefined, _cash:Object

class Equity {

    constructor() {
        //
    }

    /**
    * 
    * @member {String} equityValue
    */

    get equityValue():String { return _equityValue; }
    set equityValue(value:String):void {
        _equityValue = value;
    }
    /**
    * 
    * @member {Object} cash
    */

    get cash():Object { return _cash; }
    set cash(value:Object):void {
        _cash = value;
    }

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        _equityValue = undefined;
        _cash = undefined;
    }

    toString() {
        return JSON.stringify({
            equityValue: _equityValue,cash: _cash, 
        });
    }

};

module.exports = new Equity();




