'use strict';



/**
* The Fundamental model module.
* @module model/Fundamental
* @version 1.4.114
**/

/**
* Constructs a new <code>Fundamental</code>.
* @alias module:model/Fundamental
* @class
*/


var _instrumentID:String = undefined, _symbol:String = undefined, _companyName:String = undefined, _yesterdayClose:Number = undefined, _openPrice:Number = undefined, _bidPrice:Number = undefined, _askPrice:Number = undefined, _lowPrice:Number = undefined, _highPrice:Number = undefined, _fiftyTwoWeekLowPrice:Number = undefined, _fiftyTwoWeekHighPrice:Number = undefined, _cumulativeVolume:Number = undefined, _thirtyDayAvgVolume:Number = undefined, _marketCap:Number = undefined, _peRatio:Number = undefined, _dividendYield:Number = undefined, _earningsPerShare:Number = undefined, _dividend:Number = undefined, _dividend:Number

class Fundamental {

    constructor() {
        //
    }

    /**
    * 
    * @member {String} instrumentID
    */

    get instrumentID():String { return _instrumentID; }
    set instrumentID(value:String):void {
        _instrumentID = value;
    }
    /**
    * 
    * @member {String} symbol
    */

    get symbol():String { return _symbol; }
    set symbol(value:String):void {
        _symbol = value;
    }
    /**
    * 
    * @member {String} companyName
    */

    get companyName():String { return _companyName; }
    set companyName(value:String):void {
        _companyName = value;
    }
    /**
    * 
    * @member {Number} yesterdayClose
    */

    get yesterdayClose():Number { return _yesterdayClose; }
    set yesterdayClose(value:Number):void {
        _yesterdayClose = value;
    }
    /**
    * 
    * @member {Number} openPrice
    */

    get openPrice():Number { return _openPrice; }
    set openPrice(value:Number):void {
        _openPrice = value;
    }
    /**
    * 
    * @member {Number} bidPrice
    */

    get bidPrice():Number { return _bidPrice; }
    set bidPrice(value:Number):void {
        _bidPrice = value;
    }
    /**
    * 
    * @member {Number} askPrice
    */

    get askPrice():Number { return _askPrice; }
    set askPrice(value:Number):void {
        _askPrice = value;
    }
    /**
    * 
    * @member {Number} lowPrice
    */

    get lowPrice():Number { return _lowPrice; }
    set lowPrice(value:Number):void {
        _lowPrice = value;
    }
    /**
    * 
    * @member {Number} highPrice
    */

    get highPrice():Number { return _highPrice; }
    set highPrice(value:Number):void {
        _highPrice = value;
    }
    /**
    * 
    * @member {Number} fiftyTwoWeekLowPrice
    */

    get fiftyTwoWeekLowPrice():Number { return _fiftyTwoWeekLowPrice; }
    set fiftyTwoWeekLowPrice(value:Number):void {
        _fiftyTwoWeekLowPrice = value;
    }
    /**
    * 
    * @member {Number} fiftyTwoWeekHighPrice
    */

    get fiftyTwoWeekHighPrice():Number { return _fiftyTwoWeekHighPrice; }
    set fiftyTwoWeekHighPrice(value:Number):void {
        _fiftyTwoWeekHighPrice = value;
    }
    /**
    * 
    * @member {Number} cumulativeVolume
    */

    get cumulativeVolume():Number { return _cumulativeVolume; }
    set cumulativeVolume(value:Number):void {
        _cumulativeVolume = value;
    }
    /**
    * 
    * @member {Number} thirtyDayAvgVolume
    */

    get thirtyDayAvgVolume():Number { return _thirtyDayAvgVolume; }
    set thirtyDayAvgVolume(value:Number):void {
        _thirtyDayAvgVolume = value;
    }
    /**
    * 
    * @member {Number} marketCap
    */

    get marketCap():Number { return _marketCap; }
    set marketCap(value:Number):void {
        _marketCap = value;
    }
    /**
    * 
    * @member {Number} peRatio
    */

    get peRatio():Number { return _peRatio; }
    set peRatio(value:Number):void {
        _peRatio = value;
    }
    /**
    * 
    * @member {Number} dividendYield
    */

    get dividendYield():Number { return _dividendYield; }
    set dividendYield(value:Number):void {
        _dividendYield = value;
    }
    /**
    * 
    * @member {Number} earningsPerShare
    */

    get earningsPerShare():Number { return _earningsPerShare; }
    set earningsPerShare(value:Number):void {
        _earningsPerShare = value;
    }
    /**
    * 
    * @member {Number} dividend
    */

    get dividend():Number { return _dividend; }
    set dividend(value:Number):void {
        _dividend = value;
    }

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        _instrumentID = undefined;
        _symbol = undefined;
        _companyName = undefined;
        _yesterdayClose = undefined;
        _openPrice = undefined;
        _bidPrice = undefined;
        _askPrice = undefined;
        _lowPrice = undefined;
        _highPrice = undefined;
        _fiftyTwoWeekLowPrice = undefined;
        _fiftyTwoWeekHighPrice = undefined;
        _cumulativeVolume = undefined;
        _thirtyDayAvgVolume = undefined;
        _marketCap = undefined;
        _peRatio = undefined;
        _dividendYield = undefined;
        _earningsPerShare = undefined;
        _dividend = undefined;
    }

    toString() {
        return JSON.stringify({
            instrumentID: _instrumentID,symbol: _symbol,companyName: _companyName,yesterdayClose: _yesterdayClose,openPrice: _openPrice,bidPrice: _bidPrice,askPrice: _askPrice,lowPrice: _lowPrice,highPrice: _highPrice,fiftyTwoWeekLowPrice: _fiftyTwoWeekLowPrice,fiftyTwoWeekHighPrice: _fiftyTwoWeekHighPrice,cumulativeVolume: _cumulativeVolume,thirtyDayAvgVolume: _thirtyDayAvgVolume,marketCap: _marketCap,peRatio: _peRatio,dividendYield: _dividendYield,earningsPerShare: _earningsPerShare,dividend: _dividend, 
        });
    }

};

module.exports = new Fundamental();




