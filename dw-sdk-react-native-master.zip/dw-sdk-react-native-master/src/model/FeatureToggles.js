'use strict';



/**
* The FeatureToggles model module.
* @module model/FeatureToggles
* @version 1.4.114
**/

/**
* Constructs a new <code>FeatureToggles</code>.
* @alias module:model/FeatureToggles
* @class
*/


var

class FeatureToggles {

    constructor() {
        //
    }


    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
    }

    toString() {
        return JSON.stringify({
             
        });
    }

};

module.exports = new FeatureToggles();




