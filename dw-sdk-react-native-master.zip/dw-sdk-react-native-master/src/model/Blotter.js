'use strict';



/**
* The Blotter model module.
* @module model/Blotter
* @version 1.4.114
**/

/**
* Constructs a new <code>Blotter</code>.
* @alias module:model/Blotter
* @class
*/


var _accountID:String = undefined, _accountNo:String = undefined, _cash:Object = undefined, _cash:Object

class Blotter {

    constructor() {
        //
    }

    /**
    * 
    * @member {String} accountID
    */

    get accountID():String { return _accountID; }
    set accountID(value:String):void {
        _accountID = value;
    }
    /**
    * 
    * @member {String} accountNo
    */

    get accountNo():String { return _accountNo; }
    set accountNo(value:String):void {
        _accountNo = value;
    }
    /**
    * 
    * @member {Object} cash
    */

    get cash():Object { return _cash; }
    set cash(value:Object):void {
        _cash = value;
    }

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        _accountID = undefined;
        _accountNo = undefined;
        _cash = undefined;
    }

    toString() {
        return JSON.stringify({
            accountID: _accountID,accountNo: _accountNo,cash: _cash, 
        });
    }

};

module.exports = new Blotter();




