'use strict';



/**
* The Orders model module.
* @module model/Orders
* @version 1.4.114
**/

/**
* Constructs a new <code>Orders</code>.
* @alias module:model/Orders
* @class
*/


var _orderID:String = undefined, _orderNo:String = undefined, _createdWhen:String = undefined, _symbol:String = undefined, _cumQty:String = undefined, _orderStatus:String = undefined, _orderType:String = undefined, _orderQty:String = undefined, _limitPrice:String = undefined, _side:String = undefined, _orderCashAmt:String = undefined, _stopPrice:String = undefined, _stopPrice:String

class Orders {

    constructor() {
        //
    }

    /**
    * 
    * @member {String} orderID
    */

    get orderID():String { return _orderID; }
    set orderID(value:String):void {
        _orderID = value;
    }
    /**
    * 
    * @member {String} orderNo
    */

    get orderNo():String { return _orderNo; }
    set orderNo(value:String):void {
        _orderNo = value;
    }
    /**
    * 
    * @member {String} createdWhen
    */

    get createdWhen():String { return _createdWhen; }
    set createdWhen(value:String):void {
        _createdWhen = value;
    }
    /**
    * 
    * @member {String} symbol
    */

    get symbol():String { return _symbol; }
    set symbol(value:String):void {
        _symbol = value;
    }
    /**
    * 
    * @member {String} cumQty
    */

    get cumQty():String { return _cumQty; }
    set cumQty(value:String):void {
        _cumQty = value;
    }
    /**
    * 
    * @member {String} orderStatus
    */

    get orderStatus():String { return _orderStatus; }
    set orderStatus(value:String):void {
        _orderStatus = value;
    }
    /**
    * 
    * @member {String} orderType
    */

    get orderType():String { return _orderType; }
    set orderType(value:String):void {
        _orderType = value;
    }
    /**
    * 
    * @member {String} orderQty
    */

    get orderQty():String { return _orderQty; }
    set orderQty(value:String):void {
        _orderQty = value;
    }
    /**
    * 
    * @member {String} limitPrice
    */

    get limitPrice():String { return _limitPrice; }
    set limitPrice(value:String):void {
        _limitPrice = value;
    }
    /**
    * 
    * @member {String} side
    */

    get side():String { return _side; }
    set side(value:String):void {
        _side = value;
    }
    /**
    * 
    * @member {String} orderCashAmt
    */

    get orderCashAmt():String { return _orderCashAmt; }
    set orderCashAmt(value:String):void {
        _orderCashAmt = value;
    }
    /**
    * 
    * @member {String} stopPrice
    */

    get stopPrice():String { return _stopPrice; }
    set stopPrice(value:String):void {
        _stopPrice = value;
    }

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        _orderID = undefined;
        _orderNo = undefined;
        _createdWhen = undefined;
        _symbol = undefined;
        _cumQty = undefined;
        _orderStatus = undefined;
        _orderType = undefined;
        _orderQty = undefined;
        _limitPrice = undefined;
        _side = undefined;
        _orderCashAmt = undefined;
        _stopPrice = undefined;
    }

    toString() {
        return JSON.stringify({
            orderID: _orderID,orderNo: _orderNo,createdWhen: _createdWhen,symbol: _symbol,cumQty: _cumQty,orderStatus: _orderStatus,orderType: _orderType,orderQty: _orderQty,limitPrice: _limitPrice,side: _side,orderCashAmt: _orderCashAmt,stopPrice: _stopPrice, 
        });
    }

};

module.exports = new Orders();




