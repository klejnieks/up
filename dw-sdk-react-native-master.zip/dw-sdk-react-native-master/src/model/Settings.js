'use strict';



/**
* The Settings model module.
* @module model/Settings
* @version 1.4.114
**/

/**
* Constructs a new <code>Settings</code>.
* @alias module:model/Settings
* @class
*/


var _marketState:Number = undefined, _wlpid:String = undefined, _quotesRefreshRate:Number = undefined, _quotesFailureThreshold:Number = undefined, _quotesFailureTime:Number = undefined, _accountRefreshRate:Number = undefined, _maxOrderStatusAttempts:Number = undefined, _starterFunds:Number = undefined, _defaultLanguageID:String = undefined, _serviceHost:String = undefined, _serviceHost:String

class Settings {

    constructor() {
        //
    }

    /**
    * 
    * @member {Number} marketState
    */

    get marketState():Number { return _marketState; }
    set marketState(value:Number):void {
        _marketState = value;
    }
    /**
    * 
    * @member {String} wlpid
    */

    get wlpid():String { return _wlpid; }
    set wlpid(value:String):void {
        _wlpid = value;
    }
    /**
    * 
    * @member {Number} quotesRefreshRate
    */

    get quotesRefreshRate():Number { return _quotesRefreshRate; }
    set quotesRefreshRate(value:Number):void {
        _quotesRefreshRate = value;
    }
    /**
    * 
    * @member {Number} quotesFailureThreshold
    */

    get quotesFailureThreshold():Number { return _quotesFailureThreshold; }
    set quotesFailureThreshold(value:Number):void {
        _quotesFailureThreshold = value;
    }
    /**
    * 
    * @member {Number} quotesFailureTime
    */

    get quotesFailureTime():Number { return _quotesFailureTime; }
    set quotesFailureTime(value:Number):void {
        _quotesFailureTime = value;
    }
    /**
    * 
    * @member {Number} accountRefreshRate
    */

    get accountRefreshRate():Number { return _accountRefreshRate; }
    set accountRefreshRate(value:Number):void {
        _accountRefreshRate = value;
    }
    /**
    * 
    * @member {Number} maxOrderStatusAttempts
    */

    get maxOrderStatusAttempts():Number { return _maxOrderStatusAttempts; }
    set maxOrderStatusAttempts(value:Number):void {
        _maxOrderStatusAttempts = value;
    }
    /**
    * 
    * @member {Number} starterFunds
    */

    get starterFunds():Number { return _starterFunds; }
    set starterFunds(value:Number):void {
        _starterFunds = value;
    }
    /**
    * 
    * @member {String} defaultLanguageID
    */

    get defaultLanguageID():String { return _defaultLanguageID; }
    set defaultLanguageID(value:String):void {
        _defaultLanguageID = value;
    }
    /**
    * 
    * @member {String} serviceHost
    */

    get serviceHost():String { return _serviceHost; }
    set serviceHost(value:String):void {
        _serviceHost = value;
    }

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        _marketState = undefined;
        _wlpid = undefined;
        _quotesRefreshRate = undefined;
        _quotesFailureThreshold = undefined;
        _quotesFailureTime = undefined;
        _accountRefreshRate = undefined;
        _maxOrderStatusAttempts = undefined;
        _starterFunds = undefined;
        _defaultLanguageID = undefined;
        _serviceHost = undefined;
    }

    toString() {
        return JSON.stringify({
            marketState: _marketState,wlpid: _wlpid,quotesRefreshRate: _quotesRefreshRate,quotesFailureThreshold: _quotesFailureThreshold,quotesFailureTime: _quotesFailureTime,accountRefreshRate: _accountRefreshRate,maxOrderStatusAttempts: _maxOrderStatusAttempts,starterFunds: _starterFunds,defaultLanguageID: _defaultLanguageID,serviceHost: _serviceHost, 
        });
    }

};

module.exports = new Settings();




