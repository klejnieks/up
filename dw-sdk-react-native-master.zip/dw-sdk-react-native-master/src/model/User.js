'use strict';



/**
* The User model module.
* @module model/User
* @version 1.4.114
**/

/**
* Constructs a new <code>User</code>.
* @alias module:model/User
* @class
*/


var _name:String = undefined, _appTypeID:Number = undefined, _accounts:[Account] = undefined, _selectedAccount:Object = undefined, _guest:Boolean = undefined, _statusMsg:String = undefined, _referralCode:String = undefined, _featureToggle:Object = undefined, _ackSignedWhen:String = undefined, _addressLine1:String = undefined, _avatarUrl:String = undefined, _city:String = undefined, _coinBalance:String = undefined, _commisionRate:String = undefined, _countryID:String = undefined, _displayName:String = undefined, _emailAddress1:String = undefined, _firstName:String = undefined, _gender:String = undefined, _languageID:String = undefined, _lastName:String = undefined, _phoneHome:String = undefined, _sessionKey:String = undefined, _stateProvince:String = undefined, _userID:String = undefined, _username:String = undefined, _wlpID:String = undefined, _zipPostalCode:String = undefined, _status:Integer = undefined, _usCitizen:Boolean = undefined, _updatedWhen:String = undefined, _lastLoginWhen:String = undefined, _rebateCfdValue:Integer = undefined, _rebateEquityValue:Integer = undefined, _rebateFxValue:Integer = undefined, _brandAmbassador:Boolean = undefined, _employerBusiness:String = undefined, _employmentStatus:String = undefined, _statementPrint:Boolean = undefined, _confirmPrint:Boolean = undefined, _citizenship:String = undefined, _createdWhen:String = undefined, _addressProofReviewWhen:String = undefined, _approvedWhen:String = undefined, _approvedBy:String = undefined, _kycWhen:String = undefined, _pictureReviewBy:String = undefined, _pictureReviewWhen:String = undefined, _annualIncome:String = undefined, _userAttributes:Object = undefined, _userAttributes:Object

class User {

    constructor() {
        //
    }

    /**
    * 
    * @member {String} name
    */

    get name():String { return _name; }
    set name(value:String):void {
        _name = value;
    }
    /**
    * 
    * @member {Number} appTypeID
    */

    get appTypeID():Number { return _appTypeID; }
    set appTypeID(value:Number):void {
        _appTypeID = value;
    }
    /**
    * 
    * @member {Array.<module:model/Account>} accounts
    */

    get accounts():[Account] { return _accounts; }
    set accounts(value:[Account]):void {
        _accounts = value;
    }
    /**
    * 
    * @member {Object} selectedAccount
    */

    get selectedAccount():Object { return _selectedAccount; }
    set selectedAccount(value:Object):void {
        _selectedAccount = value;
    }
    /**
    * 
    * @member {Boolean} guest
    */

    get guest():Boolean { return _guest; }
    set guest(value:Boolean):void {
        _guest = value;
    }
    /**
    * 
    * @member {String} statusMsg
    */

    get statusMsg():String { return _statusMsg; }
    set statusMsg(value:String):void {
        _statusMsg = value;
    }
    /**
    * 
    * @member {String} referralCode
    */

    get referralCode():String { return _referralCode; }
    set referralCode(value:String):void {
        _referralCode = value;
    }
    /**
    * 
    * @member {Object} featureToggle
    */

    get featureToggle():Object { return _featureToggle; }
    set featureToggle(value:Object):void {
        _featureToggle = value;
    }
    /**
    * 
    * @member {String} ackSignedWhen
    */

    get ackSignedWhen():String { return _ackSignedWhen; }
    set ackSignedWhen(value:String):void {
        _ackSignedWhen = value;
    }
    /**
    * 
    * @member {String} addressLine1
    */

    get addressLine1():String { return _addressLine1; }
    set addressLine1(value:String):void {
        _addressLine1 = value;
    }
    /**
    * 
    * @member {String} avatarUrl
    */

    get avatarUrl():String { return _avatarUrl; }
    set avatarUrl(value:String):void {
        _avatarUrl = value;
    }
    /**
    * 
    * @member {String} city
    */

    get city():String { return _city; }
    set city(value:String):void {
        _city = value;
    }
    /**
    * 
    * @member {String} coinBalance
    */

    get coinBalance():String { return _coinBalance; }
    set coinBalance(value:String):void {
        _coinBalance = value;
    }
    /**
    * 
    * @member {String} commisionRate
    */

    get commisionRate():String { return _commisionRate; }
    set commisionRate(value:String):void {
        _commisionRate = value;
    }
    /**
    * 
    * @member {String} countryID
    */

    get countryID():String { return _countryID; }
    set countryID(value:String):void {
        _countryID = value;
    }
    /**
    * 
    * @member {String} displayName
    */

    get displayName():String { return _displayName; }
    set displayName(value:String):void {
        _displayName = value;
    }
    /**
    * 
    * @member {String} emailAddress1
    */

    get emailAddress1():String { return _emailAddress1; }
    set emailAddress1(value:String):void {
        _emailAddress1 = value;
    }
    /**
    * 
    * @member {String} firstName
    */

    get firstName():String { return _firstName; }
    set firstName(value:String):void {
        _firstName = value;
    }
    /**
    * 
    * @member {String} gender
    */

    get gender():String { return _gender; }
    set gender(value:String):void {
        _gender = value;
    }
    /**
    * 
    * @member {String} languageID
    */

    get languageID():String { return _languageID; }
    set languageID(value:String):void {
        _languageID = value;
    }
    /**
    * 
    * @member {String} lastName
    */

    get lastName():String { return _lastName; }
    set lastName(value:String):void {
        _lastName = value;
    }
    /**
    * 
    * @member {String} phoneHome
    */

    get phoneHome():String { return _phoneHome; }
    set phoneHome(value:String):void {
        _phoneHome = value;
    }
    /**
    * 
    * @member {String} sessionKey
    */

    get sessionKey():String { return _sessionKey; }
    set sessionKey(value:String):void {
        _sessionKey = value;
    }
    /**
    * 
    * @member {String} stateProvince
    */

    get stateProvince():String { return _stateProvince; }
    set stateProvince(value:String):void {
        _stateProvince = value;
    }
    /**
    * 
    * @member {String} userID
    */

    get userID():String { return _userID; }
    set userID(value:String):void {
        _userID = value;
    }
    /**
    * 
    * @member {String} username
    */

    get username():String { return _username; }
    set username(value:String):void {
        _username = value;
    }
    /**
    * 
    * @member {String} wlpID
    */

    get wlpID():String { return _wlpID; }
    set wlpID(value:String):void {
        _wlpID = value;
    }
    /**
    * 
    * @member {String} zipPostalCode
    */

    get zipPostalCode():String { return _zipPostalCode; }
    set zipPostalCode(value:String):void {
        _zipPostalCode = value;
    }
    /**
    * 
    * @member {Integer} status
    */

    get status():Integer { return _status; }
    set status(value:Integer):void {
        _status = value;
    }
    /**
    * 
    * @member {Boolean} usCitizen
    */

    get usCitizen():Boolean { return _usCitizen; }
    set usCitizen(value:Boolean):void {
        _usCitizen = value;
    }
    /**
    * 
    * @member {String} updatedWhen
    */

    get updatedWhen():String { return _updatedWhen; }
    set updatedWhen(value:String):void {
        _updatedWhen = value;
    }
    /**
    * 
    * @member {String} lastLoginWhen
    */

    get lastLoginWhen():String { return _lastLoginWhen; }
    set lastLoginWhen(value:String):void {
        _lastLoginWhen = value;
    }
    /**
    * 
    * @member {Integer} rebateCfdValue
    */

    get rebateCfdValue():Integer { return _rebateCfdValue; }
    set rebateCfdValue(value:Integer):void {
        _rebateCfdValue = value;
    }
    /**
    * 
    * @member {Integer} rebateEquityValue
    */

    get rebateEquityValue():Integer { return _rebateEquityValue; }
    set rebateEquityValue(value:Integer):void {
        _rebateEquityValue = value;
    }
    /**
    * 
    * @member {Integer} rebateFxValue
    */

    get rebateFxValue():Integer { return _rebateFxValue; }
    set rebateFxValue(value:Integer):void {
        _rebateFxValue = value;
    }
    /**
    * 
    * @member {Boolean} brandAmbassador
    */

    get brandAmbassador():Boolean { return _brandAmbassador; }
    set brandAmbassador(value:Boolean):void {
        _brandAmbassador = value;
    }
    /**
    * 
    * @member {String} employerBusiness
    */

    get employerBusiness():String { return _employerBusiness; }
    set employerBusiness(value:String):void {
        _employerBusiness = value;
    }
    /**
    * 
    * @member {String} employmentStatus
    */

    get employmentStatus():String { return _employmentStatus; }
    set employmentStatus(value:String):void {
        _employmentStatus = value;
    }
    /**
    * 
    * @member {Boolean} statementPrint
    */

    get statementPrint():Boolean { return _statementPrint; }
    set statementPrint(value:Boolean):void {
        _statementPrint = value;
    }
    /**
    * 
    * @member {Boolean} confirmPrint
    */

    get confirmPrint():Boolean { return _confirmPrint; }
    set confirmPrint(value:Boolean):void {
        _confirmPrint = value;
    }
    /**
    * 
    * @member {String} citizenship
    */

    get citizenship():String { return _citizenship; }
    set citizenship(value:String):void {
        _citizenship = value;
    }
    /**
    * 
    * @member {String} createdWhen
    */

    get createdWhen():String { return _createdWhen; }
    set createdWhen(value:String):void {
        _createdWhen = value;
    }
    /**
    * 
    * @member {String} addressProofReviewWhen
    */

    get addressProofReviewWhen():String { return _addressProofReviewWhen; }
    set addressProofReviewWhen(value:String):void {
        _addressProofReviewWhen = value;
    }
    /**
    * 
    * @member {String} approvedWhen
    */

    get approvedWhen():String { return _approvedWhen; }
    set approvedWhen(value:String):void {
        _approvedWhen = value;
    }
    /**
    * 
    * @member {String} approvedBy
    */

    get approvedBy():String { return _approvedBy; }
    set approvedBy(value:String):void {
        _approvedBy = value;
    }
    /**
    * 
    * @member {String} kycWhen
    */

    get kycWhen():String { return _kycWhen; }
    set kycWhen(value:String):void {
        _kycWhen = value;
    }
    /**
    * 
    * @member {String} pictureReviewBy
    */

    get pictureReviewBy():String { return _pictureReviewBy; }
    set pictureReviewBy(value:String):void {
        _pictureReviewBy = value;
    }
    /**
    * 
    * @member {String} pictureReviewWhen
    */

    get pictureReviewWhen():String { return _pictureReviewWhen; }
    set pictureReviewWhen(value:String):void {
        _pictureReviewWhen = value;
    }
    /**
    * 
    * @member {String} annualIncome
    */

    get annualIncome():String { return _annualIncome; }
    set annualIncome(value:String):void {
        _annualIncome = value;
    }
    /**
    * 
    * @member {Object} userAttributes
    */

    get userAttributes():Object { return _userAttributes; }
    set userAttributes(value:Object):void {
        _userAttributes = value;
    }

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        _name = undefined;
        _appTypeID = undefined;
        _accounts = undefined;
        _selectedAccount = undefined;
        _guest = undefined;
        _statusMsg = undefined;
        _referralCode = undefined;
        _featureToggle = undefined;
        _ackSignedWhen = undefined;
        _addressLine1 = undefined;
        _avatarUrl = undefined;
        _city = undefined;
        _coinBalance = undefined;
        _commisionRate = undefined;
        _countryID = undefined;
        _displayName = undefined;
        _emailAddress1 = undefined;
        _firstName = undefined;
        _gender = undefined;
        _languageID = undefined;
        _lastName = undefined;
        _phoneHome = undefined;
        _sessionKey = undefined;
        _stateProvince = undefined;
        _userID = undefined;
        _username = undefined;
        _wlpID = undefined;
        _zipPostalCode = undefined;
        _status = undefined;
        _usCitizen = undefined;
        _updatedWhen = undefined;
        _lastLoginWhen = undefined;
        _rebateCfdValue = undefined;
        _rebateEquityValue = undefined;
        _rebateFxValue = undefined;
        _brandAmbassador = undefined;
        _employerBusiness = undefined;
        _employmentStatus = undefined;
        _statementPrint = undefined;
        _confirmPrint = undefined;
        _citizenship = undefined;
        _createdWhen = undefined;
        _addressProofReviewWhen = undefined;
        _approvedWhen = undefined;
        _approvedBy = undefined;
        _kycWhen = undefined;
        _pictureReviewBy = undefined;
        _pictureReviewWhen = undefined;
        _annualIncome = undefined;
        _userAttributes = undefined;
    }

    toString() {
        return JSON.stringify({
            name: _name,appTypeID: _appTypeID,accounts: _accounts,selectedAccount: _selectedAccount,guest: _guest,statusMsg: _statusMsg,referralCode: _referralCode,featureToggle: _featureToggle,ackSignedWhen: _ackSignedWhen,addressLine1: _addressLine1,avatarUrl: _avatarUrl,city: _city,coinBalance: _coinBalance,commisionRate: _commisionRate,countryID: _countryID,displayName: _displayName,emailAddress1: _emailAddress1,firstName: _firstName,gender: _gender,languageID: _languageID,lastName: _lastName,phoneHome: _phoneHome,sessionKey: _sessionKey,stateProvince: _stateProvince,userID: _userID,username: _username,wlpID: _wlpID,zipPostalCode: _zipPostalCode,status: _status,usCitizen: _usCitizen,updatedWhen: _updatedWhen,lastLoginWhen: _lastLoginWhen,rebateCfdValue: _rebateCfdValue,rebateEquityValue: _rebateEquityValue,rebateFxValue: _rebateFxValue,brandAmbassador: _brandAmbassador,employerBusiness: _employerBusiness,employmentStatus: _employmentStatus,statementPrint: _statementPrint,confirmPrint: _confirmPrint,citizenship: _citizenship,createdWhen: _createdWhen,addressProofReviewWhen: _addressProofReviewWhen,approvedWhen: _approvedWhen,approvedBy: _approvedBy,kycWhen: _kycWhen,pictureReviewBy: _pictureReviewBy,pictureReviewWhen: _pictureReviewWhen,annualIncome: _annualIncome,userAttributes: _userAttributes, 
        });
    }

};

module.exports = new User();




