'use strict';



/**
* The Endpoints model module.
* @module model/Endpoints
* @version 1.4.114
**/

/**
* Constructs a new <code>Endpoints</code>.
* @alias module:model/Endpoints
* @class
*/


var

class Endpoints {

    constructor() {
        //
    }


    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
    }

    toString() {
        return JSON.stringify({
             
        });
    }

};

module.exports = new Endpoints();




