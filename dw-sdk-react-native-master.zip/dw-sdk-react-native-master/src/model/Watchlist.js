'use strict';



/**
* The Watchlist model module.
* @module model/Watchlist
* @version 1.4.114
**/

/**
* Constructs a new <code>Watchlist</code>.
* @alias module:model/Watchlist
* @class
*/


var _userID:String = undefined, _key:String = undefined, _value:String = undefined, _value:String

class Watchlist {

    constructor() {
        //
    }

    /**
    * 
    * @member {String} userID
    */

    get userID():String { return _userID; }
    set userID(value:String):void {
        _userID = value;
    }
    /**
    * 
    * @member {String} key
    */

    get key():String { return _key; }
    set key(value:String):void {
        _key = value;
    }
    /**
    * 
    * @member {String} value
    */

    get value():String { return _value; }
    set value(value:String):void {
        _value = value;
    }

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        _userID = undefined;
        _key = undefined;
        _value = undefined;
    }

    toString() {
        return JSON.stringify({
            userID: _userID,key: _key,value: _value, 
        });
    }

};

module.exports = new Watchlist();




