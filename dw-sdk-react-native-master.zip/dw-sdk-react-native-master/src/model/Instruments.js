'use strict';



/**
* The Instruments model module.
* @module model/Instruments
* @version 1.4.114
**/

/**
* Constructs a new <code>Instruments</code>.
* @alias module:model/Instruments
* @class
*/


var

class Instruments {

    constructor() {
        //
    }


    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
    }

    toString() {
        return JSON.stringify({
             
        });
    }

};

module.exports = new Instruments();




