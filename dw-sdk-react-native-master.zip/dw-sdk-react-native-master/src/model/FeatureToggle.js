'use strict';



/**
* The FeatureToggle model module.
* @module model/FeatureToggle
* @version 1.4.114
**/

/**
* Constructs a new <code>FeatureToggle</code>.
* @alias module:model/FeatureToggle
* @class
*/


var _featureToggleID:String = undefined, _enabled:Boolean = undefined, _enabled:Boolean

class FeatureToggle {

    constructor() {
        //
    }

    /**
    * 
    * @member {String} featureToggleID
    */

    get featureToggleID():String { return _featureToggleID; }
    set featureToggleID(value:String):void {
        _featureToggleID = value;
    }
    /**
    * 
    * @member {Boolean} enabled
    */

    get enabled():Boolean { return _enabled; }
    set enabled(value:Boolean):void {
        _enabled = value;
    }

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        _featureToggleID = undefined;
        _enabled = undefined;
    }

    toString() {
        return JSON.stringify({
            featureToggleID: _featureToggleID,enabled: _enabled, 
        });
    }

};

module.exports = new FeatureToggle();




