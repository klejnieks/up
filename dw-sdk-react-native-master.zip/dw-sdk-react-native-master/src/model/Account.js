'use strict';



/**
* The Account model module.
* @module model/Account
* @version 1.4.114
**/

/**
* Constructs a new <code>Account</code>.
* @alias module:model/Account
* @class
*/


var _nickname:String = undefined, _accountID:String = undefined, _accountNo:String = undefined, _accountType:String = undefined, _createdWhen:String = undefined, _currencyID:String = undefined, _freeTradeBalance:Number = undefined, _goodFaithViolations:Number = undefined, _ibID:String = undefined, _interestFree:Boolean = undefined, _longOnly:Boolean = undefined, _margin:Number = undefined, _openedWhen:String = undefined, _patternDayTrades:Number = undefined, _status:Number = undefined, _tradingType:String = undefined, _commisionSchedule:Object = undefined, _equityValue:Number = undefined, _cash:Object = undefined, _positions:Object = undefined, _positionsAsSymbols:Object = undefined, _positionsBySector:Object = undefined, _orders:Object = undefined, _lifetimePl:Number = undefined, _lifetimePlPercent:Number = undefined, _dailyPl:Number = undefined, _dailyPlPercent:Number = undefined, _hasPosition:Boolean = undefined, _hasPosition:Boolean

class Account {

    constructor() {
        //
    }

    /**
    * 
    * @member {String} nickname
    */

    get nickname():String { return _nickname; }
    set nickname(value:String):void {
        _nickname = value;
    }
    /**
    * 
    * @member {String} accountID
    */

    get accountID():String { return _accountID; }
    set accountID(value:String):void {
        _accountID = value;
    }
    /**
    * 
    * @member {String} accountNo
    */

    get accountNo():String { return _accountNo; }
    set accountNo(value:String):void {
        _accountNo = value;
    }
    /**
    * 
    * @member {String} accountType
    */

    get accountType():String { return _accountType; }
    set accountType(value:String):void {
        _accountType = value;
    }
    /**
    * 
    * @member {String} createdWhen
    */

    get createdWhen():String { return _createdWhen; }
    set createdWhen(value:String):void {
        _createdWhen = value;
    }
    /**
    * 
    * @member {String} currencyID
    */

    get currencyID():String { return _currencyID; }
    set currencyID(value:String):void {
        _currencyID = value;
    }
    /**
    * 
    * @member {Number} freeTradeBalance
    */

    get freeTradeBalance():Number { return _freeTradeBalance; }
    set freeTradeBalance(value:Number):void {
        _freeTradeBalance = value;
    }
    /**
    * 
    * @member {Number} goodFaithViolations
    */

    get goodFaithViolations():Number { return _goodFaithViolations; }
    set goodFaithViolations(value:Number):void {
        _goodFaithViolations = value;
    }
    /**
    * 
    * @member {String} ibID
    */

    get ibID():String { return _ibID; }
    set ibID(value:String):void {
        _ibID = value;
    }
    /**
    * 
    * @member {Boolean} interestFree
    */

    get interestFree():Boolean { return _interestFree; }
    set interestFree(value:Boolean):void {
        _interestFree = value;
    }
    /**
    * 
    * @member {Boolean} longOnly
    */

    get longOnly():Boolean { return _longOnly; }
    set longOnly(value:Boolean):void {
        _longOnly = value;
    }
    /**
    * 
    * @member {Number} margin
    */

    get margin():Number { return _margin; }
    set margin(value:Number):void {
        _margin = value;
    }
    /**
    * 
    * @member {String} openedWhen
    */

    get openedWhen():String { return _openedWhen; }
    set openedWhen(value:String):void {
        _openedWhen = value;
    }
    /**
    * 
    * @member {Number} patternDayTrades
    */

    get patternDayTrades():Number { return _patternDayTrades; }
    set patternDayTrades(value:Number):void {
        _patternDayTrades = value;
    }
    /**
    * 
    * @member {Number} status
    */

    get status():Number { return _status; }
    set status(value:Number):void {
        _status = value;
    }
    /**
    * 
    * @member {String} tradingType
    */

    get tradingType():String { return _tradingType; }
    set tradingType(value:String):void {
        _tradingType = value;
    }
    /**
    * 
    * @member {Object} commisionSchedule
    */

    get commisionSchedule():Object { return _commisionSchedule; }
    set commisionSchedule(value:Object):void {
        _commisionSchedule = value;
    }
    /**
    * 
    * @member {Number} equityValue
    */

    get equityValue():Number { return _equityValue; }
    set equityValue(value:Number):void {
        _equityValue = value;
    }
    /**
    * 
    * @member {Object} cash
    */

    get cash():Object { return _cash; }
    set cash(value:Object):void {
        _cash = value;
    }
    /**
    * 
    * @member {Object} positions
    */

    get positions():Object { return _positions; }
    set positions(value:Object):void {
        _positions = value;
    }
    /**
    * 
    * @member {Object} positionsAsSymbols
    */

    get positionsAsSymbols():Object { return _positionsAsSymbols; }
    set positionsAsSymbols(value:Object):void {
        _positionsAsSymbols = value;
    }
    /**
    * 
    * @member {Object} positionsBySector
    */

    get positionsBySector():Object { return _positionsBySector; }
    set positionsBySector(value:Object):void {
        _positionsBySector = value;
    }
    /**
    * 
    * @member {Object} orders
    */

    get orders():Object { return _orders; }
    set orders(value:Object):void {
        _orders = value;
    }
    /**
    * 
    * @member {Number} lifetimePl
    */

    get lifetimePl():Number { return _lifetimePl; }
    set lifetimePl(value:Number):void {
        _lifetimePl = value;
    }
    /**
    * 
    * @member {Number} lifetimePlPercent
    */

    get lifetimePlPercent():Number { return _lifetimePlPercent; }
    set lifetimePlPercent(value:Number):void {
        _lifetimePlPercent = value;
    }
    /**
    * 
    * @member {Number} dailyPl
    */

    get dailyPl():Number { return _dailyPl; }
    set dailyPl(value:Number):void {
        _dailyPl = value;
    }
    /**
    * 
    * @member {Number} dailyPlPercent
    */

    get dailyPlPercent():Number { return _dailyPlPercent; }
    set dailyPlPercent(value:Number):void {
        _dailyPlPercent = value;
    }
    /**
    * 
    * @member {Boolean} hasPosition
    */

    get hasPosition():Boolean { return _hasPosition; }
    set hasPosition(value:Boolean):void {
        _hasPosition = value;
    }

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        _nickname = undefined;
        _accountID = undefined;
        _accountNo = undefined;
        _accountType = undefined;
        _createdWhen = undefined;
        _currencyID = undefined;
        _freeTradeBalance = undefined;
        _goodFaithViolations = undefined;
        _ibID = undefined;
        _interestFree = undefined;
        _longOnly = undefined;
        _margin = undefined;
        _openedWhen = undefined;
        _patternDayTrades = undefined;
        _status = undefined;
        _tradingType = undefined;
        _commisionSchedule = undefined;
        _equityValue = undefined;
        _cash = undefined;
        _positions = undefined;
        _positionsAsSymbols = undefined;
        _positionsBySector = undefined;
        _orders = undefined;
        _lifetimePl = undefined;
        _lifetimePlPercent = undefined;
        _dailyPl = undefined;
        _dailyPlPercent = undefined;
        _hasPosition = undefined;
    }

    toString() {
        return JSON.stringify({
            nickname: _nickname,accountID: _accountID,accountNo: _accountNo,accountType: _accountType,createdWhen: _createdWhen,currencyID: _currencyID,freeTradeBalance: _freeTradeBalance,goodFaithViolations: _goodFaithViolations,ibID: _ibID,interestFree: _interestFree,longOnly: _longOnly,margin: _margin,openedWhen: _openedWhen,patternDayTrades: _patternDayTrades,status: _status,tradingType: _tradingType,commisionSchedule: _commisionSchedule,equityValue: _equityValue,cash: _cash,positions: _positions,positionsAsSymbols: _positionsAsSymbols,positionsBySector: _positionsBySector,orders: _orders,lifetimePl: _lifetimePl,lifetimePlPercent: _lifetimePlPercent,dailyPl: _dailyPl,dailyPlPercent: _dailyPlPercent,hasPosition: _hasPosition, 
        });
    }

};

module.exports = new Account();




