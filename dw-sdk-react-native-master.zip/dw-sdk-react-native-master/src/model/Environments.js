'use strict';


  /**
   * Enum class Environments.
   * @enum {}
   * @readonly
   */
  var exports = {
    /**
     * value: "UAT"
     * @const
     */
    "UAT": "UAT",
    /**
     * value: "PROD"
     * @const
     */
    "PROD": "PROD"  };

  return exports;
}));


