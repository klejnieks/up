'use strict';



/**
* The Data model module.
* @module model/Data
* @version 1.4.81
**/

/**
* Constructs a new <code>Data</code>.
* @alias module:model/Data
* @class
*/


var _languageID:String = undefined, _wlpID:String = undefined, _utm_source:String = undefined, _utm_campaign:String = undefined, _utm_content:String = undefined, _utm_medium:String = undefined, _utm_term:String = undefined, _referralCode:String = undefined, _referralCode:String

class Data {

    constructor() {
        //
    }

    /**
    * Media's name
    * @member {String} languageID
    */

    get languageID():String { return _languageID; }
    set languageID(value:String):void {
        _languageID = value;
    }
    /**
    * username for forgot password
    * @member {String} wlpID
    */

    get wlpID():String { return _wlpID; }
    set wlpID(value:String):void {
        _wlpID = value;
    }
    /**
    * username for forgot password
    * @member {String} utm_source
    */

    get utm_source():String { return _utm_source; }
    set utm_source(value:String):void {
        _utm_source = value;
    }
    /**
    * username for forgot password
    * @member {String} utm_campaign
    */

    get utm_campaign():String { return _utm_campaign; }
    set utm_campaign(value:String):void {
        _utm_campaign = value;
    }
    /**
    * username for forgot password
    * @member {String} utm_content
    */

    get utm_content():String { return _utm_content; }
    set utm_content(value:String):void {
        _utm_content = value;
    }
    /**
    * username for forgot password
    * @member {String} utm_medium
    */

    get utm_medium():String { return _utm_medium; }
    set utm_medium(value:String):void {
        _utm_medium = value;
    }
    /**
    * username for forgot password
    * @member {String} utm_term
    */

    get utm_term():String { return _utm_term; }
    set utm_term(value:String):void {
        _utm_term = value;
    }
    /**
    * username for forgot password
    * @member {String} referralCode
    */

    get referralCode():String { return _referralCode; }
    set referralCode(value:String):void {
        _referralCode = value;
    }

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        _languageID = undefined;
        _wlpID = undefined;
        _utm_source = undefined;
        _utm_campaign = undefined;
        _utm_content = undefined;
        _utm_medium = undefined;
        _utm_term = undefined;
        _referralCode = undefined;
    }

    toString() {
        return JSON.stringify({
            languageID: _languageID,wlpID: _wlpID,utm_source: _utm_source,utm_campaign: _utm_campaign,utm_content: _utm_content,utm_medium: _utm_medium,utm_term: _utm_term,referralCode: _referralCode, 
        });
    }

};

module.exports = new Data();




