'use strict';



/**
* The ErrorModel model module.
* @module model/ErrorModel
* @version 1.4.114
**/

/**
* Constructs a new <code>ErrorModel</code>.
* @alias module:model/ErrorModel
* @class
* @param code
* @param message
*/


var _code:Integer = undefined, _message:String = undefined, _message:String

class ErrorModel {

    constructor() {
        //
    }

    /**
    * 
    * @member {Integer} code
    */

    get code():Integer { return _code; }
    set code(value:Integer):void {
        _code = value;
    }
    /**
    * 
    * @member {String} message
    */

    get message():String { return _message; }
    set message(value:String):void {
        _message = value;
    }

    /**
    * destorys the current model by setting all
    * members to undefined
    */
    destroy() {
        _code = undefined;
        _message = undefined;
    }

    toString() {
        return JSON.stringify({
            code: _code,message: _message, 
        });
    }

};

module.exports = new ErrorModel();




