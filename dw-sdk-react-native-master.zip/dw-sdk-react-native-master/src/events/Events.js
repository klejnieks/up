const Events = {

    DATA_CHANGED: "dataChangedEvent",
    PORTFOLIO_DATA_TOGGLED: "portfolioDataToggledEvent",

    VIEWPORT_CHANGED: "viewportChangedEvent",

    INSTRUMENTS_CHANGED: 'instrumentsChangedEvent',
    INSTRUMENT_CHANGED: 'instrumentChangedEvent',
    INSTRUMENT_CHANGED_FROM_ROW: "instrumentChangedFromRowEvent",
    INSTRUMENT_CURSOR_CHANGED: 'instrumentCursorChangedEvent',
    SHOW_INSTRUMENT: 'showInstrumentEvent',
    HIDE_INSTRUMENT: 'hideInstrumentEvent',

    CAROUSEL_UPDATED: 'carouselUpdatedEvent',

    VIEW_CHANGED: 'viewChangedEvent',

    NEWS_ARTICLE_CHANGED: 'newsArticleChangedEvent',

    TOOLTIP_OPENED: 'tooltipOpenedEvent',
    TOOLTIP_CLOSED: 'tooltipClosedEvent',
    ALERT_OPENED: "alertOpenedEvent",
    ALERT_CLOSED: "alertClosedEvent",

    ACCOUNT_DATA_SET: 'accountDataSetEvent',
    ACCOUNT_SWITCHED: 'accountSwitchedEvent',
    USER_INFO_UPDATED: 'userInfoUpdatedEvent',

    EARNINGS_REPORTS_UPDATED: 'earningsReportsUpdated',

    WATCHLIST_CHANGED: 'watchlistChangedEvent',
    WATCHLIST_ITEM_MOVED_PORTFOLIO: 'watchlistItemMovedPortfolioEvent',

    SESSION_KEY_SET: 'sessionKeySetEvent',
    SESSION_KEY_CHANGED: 'sessionKeyChangedEvent',

    AUTHENTICATED_SUCCESSFULLY: 'authenticatedEvent',
    LOGGED_OUT: 'loggedOutEvent',

    VALIDATE_USER: 'validateUserEvent',

    HIDE_LOGIN: 'hideLoginEvent',
    HIDE_TOUR: 'hideTourEvent',
    SHOW_TOUR: 'showTourEvent',
    SIGN_UP_IN_TOUR_PRESSED: "showSignUpAfterTour",

    MARKET_STATE_CHANGED: 'marketStateChangedEvent',

    BASKET_CONTENTS_CHANGED: "basketContentsChangedEvent",

    TOGGLE_PRICE_INFO: "togglePriceInfoEvent",

    MEMORY_WARNING: "memoryWarningEvent",

    HIDE_PORTFOLIO: "hidePortfolioEvent",

    REGION_CHANGED: "regionChangedEvent",

    CHARACTER_SIZES_CALCULATED: "characterSizesCalculated",

    QUOTE_UPDATED: "quoteUpdated-",

    PORTFOLIO_FOCUS_STATUS_CHANGED: "portfolioFocusStatusChangedEvent",

    INVOKE_CAMERA: "invokeCameraEvent"

};

module.exports = Events;
