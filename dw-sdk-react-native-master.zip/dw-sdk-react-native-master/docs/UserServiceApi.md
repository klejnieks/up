# DrivewealthSdk.UserServiceApi

All URIs are relative to *http://api.drivewealth.io/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**edit**](UserServiceApi.md#edit) | **PUT** /users/{{userID}} | 
[**forgotPassword**](UserServiceApi.md#forgotPassword) | **POST** /users/passwords{{username}} | 
[**getSetting**](UserServiceApi.md#getSetting) | **GET** /users/{{userID}}/settings/{{key}} | 
[**getStatus**](UserServiceApi.md#getStatus) | **GET** /users/{{userID}}/status | 
[**getUser**](UserServiceApi.md#getUser) | **GET** /userSessions/{{sessionKey}} | 
[**getUserByUserID**](UserServiceApi.md#getUserByUserID) | **GET** /users/{{id}} | 
[**heartbeat**](UserServiceApi.md#heartbeat) | **PUT** /userSessions/{{sessionKey}}?action&#x3D;heartbeat | 
[**isUsernameAvailable**](UserServiceApi.md#isUsernameAvailable) | **GET** /users?username&#x3D;{{username}} | 
[**login**](UserServiceApi.md#login) | **POST** /userSessions | 
[**resetPassword**](UserServiceApi.md#resetPassword) | **PUT** /users/passwords/{{code}} | 
[**saveSetting**](UserServiceApi.md#saveSetting) | **POST** /users/{{userID}}/settings | 
[**setPassword**](UserServiceApi.md#setPassword) | **POST** /users/passwords/{{passwordResetID}} | 
[**signupLive**](UserServiceApi.md#signupLive) | **POST** /signups/live | 
[**signupPractice**](UserServiceApi.md#signupPractice) | **POST** /signups/practice | 


<a name="edit"></a>
# **edit**
> edit(userID, opts)



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.UserServiceApi();

var userID = "userID_example"; // String | ID of user to fetch

var opts = { 
  'data': null // Object | username for forgot password
};
apiInstance.edit(userID, opts).then(function() {
  console.log('API called successfully.');
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userID** | **String**| ID of user to fetch | 
 **data** | **Object**| username for forgot password | [optional] 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="forgotPassword"></a>
# **forgotPassword**
> User forgotPassword(userID, opts)



Returns a user based on a single ID

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.UserServiceApi();

var userID = "userID_example"; // String | ID of user to fetch

var opts = { 
  'data': null // Object | username for forgot password
};
apiInstance.forgotPassword(userID, opts).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userID** | **String**| ID of user to fetch | 
 **data** | **Object**| username for forgot password | [optional] 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getSetting"></a>
# **getSetting**
> Blotter getSetting(userID, key)



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.UserServiceApi();

var userID = "userID_example"; // String | ID of user to fetch

var key = "key_example"; // String | ID of user to fetch

apiInstance.getSetting(userID, key).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userID** | **String**| ID of user to fetch | 
 **key** | **String**| ID of user to fetch | 

### Return type

[**Blotter**](Blotter.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getStatus"></a>
# **getStatus**
> User getStatus(userID)



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.UserServiceApi();

var userID = "userID_example"; // String | ID of user to fetch

apiInstance.getStatus(userID).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userID** | **String**| ID of user to fetch | 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getUser"></a>
# **getUser**
> User getUser(sessionKey)



Returns a user based on a single ID

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.UserServiceApi();

var sessionKey = "sessionKey_example"; // String | session key of the user

apiInstance.getUser(sessionKey).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sessionKey** | **String**| session key of the user | 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getUserByUserID"></a>
# **getUserByUserID**
> User getUserByUserID(id)



Returns a user based on a single ID

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.UserServiceApi();

var id = "id_example"; // String | ID of user to fetch

apiInstance.getUserByUserID(id).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| ID of user to fetch | 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="heartbeat"></a>
# **heartbeat**
> heartbeat(sessionKey)



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.UserServiceApi();

var sessionKey = "sessionKey_example"; // String | ID of user to fetch

apiInstance.heartbeat(sessionKey).then(function() {
  console.log('API called successfully.');
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sessionKey** | **String**| ID of user to fetch | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="isUsernameAvailable"></a>
# **isUsernameAvailable**
> User isUsernameAvailable(username)



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.UserServiceApi();

var username = "username_example"; // String | ID of user to fetch

apiInstance.isUsernameAvailable(username).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **String**| ID of user to fetch | 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="login"></a>
# **login**
> User login(opts)



User Login

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.UserServiceApi();

var opts = { 
  'data': null // Object | username for forgot password
};
apiInstance.login(opts).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **data** | **Object**| username for forgot password | [optional] 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="resetPassword"></a>
# **resetPassword**
> User resetPassword(code, data)



Returns a user based on a single ID

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.UserServiceApi();

var code = "code_example"; // String | username for forgot password

var data = null; // Object | username for forgot password

apiInstance.resetPassword(code, data).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **code** | **String**| username for forgot password | 
 **data** | **Object**| username for forgot password | 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="saveSetting"></a>
# **saveSetting**
> User saveSetting(userID, opts)



Returns a user based on a single ID

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.UserServiceApi();

var userID = "userID_example"; // String | ID of user to fetch

var opts = { 
  'data': null // Object | username for forgot password
};
apiInstance.saveSetting(userID, opts).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userID** | **String**| ID of user to fetch | 
 **data** | **Object**| username for forgot password | [optional] 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="setPassword"></a>
# **setPassword**
> User setPassword(passwordResetID, opts)



Returns a user based on a single ID

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.UserServiceApi();

var passwordResetID = "passwordResetID_example"; // String | username for forgot password

var opts = { 
  'data': null // Object | username for forgot password
};
apiInstance.setPassword(passwordResetID, opts).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **passwordResetID** | **String**| username for forgot password | 
 **data** | **Object**| username for forgot password | [optional] 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="signupLive"></a>
# **signupLive**
> User signupLive(opts)



Returns a user based on a single ID

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.UserServiceApi();

var opts = { 
  'data': null // Object | User signup data object
};
apiInstance.signupLive(opts).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **data** | **Object**| User signup data object | [optional] 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="signupPractice"></a>
# **signupPractice**
> User signupPractice(opts)



Returns a user based on a single ID

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.UserServiceApi();

var opts = { 
  'data': null // Object | username for forgot password
};
apiInstance.signupPractice(opts).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **data** | **Object**| username for forgot password | [optional] 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

