# DrivewealthSdk.WatchlistServiceApi

All URIs are relative to *http://api.drivewealth.io/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get**](WatchlistServiceApi.md#get) | **GET** /users/{{userId}}/settings/watchList | 
[**save**](WatchlistServiceApi.md#save) | **POST** /users/{{userId}}/settings | 


<a name="get"></a>
# **get**
> Watchlist get(userId)



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.WatchlistServiceApi();

var userId = "userId_example"; // String | ID of user to fetch

apiInstance.get(userId).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **String**| ID of user to fetch | 

### Return type

[**Watchlist**](Watchlist.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="save"></a>
# **save**
> Watchlist save(userId, opts)



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.WatchlistServiceApi();

var userId = "userId_example"; // String | set of parameters to get chart data. ***NEEDS WORK***

var opts = { 
  'data': null // Object | username for forgot password
};
apiInstance.save(userId, opts).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **String**| set of parameters to get chart data. ***NEEDS WORK*** | 
 **data** | **Object**| username for forgot password | [optional] 

### Return type

[**Watchlist**](Watchlist.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

