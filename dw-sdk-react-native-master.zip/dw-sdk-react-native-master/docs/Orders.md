# DrivewealthSdk.Orders

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderID** | **String** |  | [optional] 
**orderNo** | **String** |  | [optional] 
**createdWhen** | **String** |  | [optional] 
**symbol** | **String** |  | [optional] 
**cumQty** | **String** |  | [optional] 
**orderStatus** | **String** |  | [optional] 
**orderType** | **String** |  | [optional] 
**orderQty** | **String** |  | [optional] 
**limitPrice** | **String** |  | [optional] 
**side** | **String** |  | [optional] 
**orderCashAmt** | **String** |  | [optional] 
**stopPrice** | **String** |  | [optional] 


