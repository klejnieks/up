# DrivewealthSdk.Equity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**equityValue** | **String** |  | [optional] 
**cash** | **Object** |  | [optional] 


