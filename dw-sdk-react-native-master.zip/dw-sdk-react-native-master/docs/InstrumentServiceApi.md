# DrivewealthSdk.InstrumentServiceApi

All URIs are relative to *http://api.drivewealth.io/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getBarsData**](InstrumentServiceApi.md#getBarsData) | **GET** /bars?instrumentID&#x3D;{{params}} | 
[**getInstrumentByID**](InstrumentServiceApi.md#getInstrumentByID) | **GET** /instruments/{{instrumentID}}?options&#x3D;F | 
[**getInstrumentBySymbols**](InstrumentServiceApi.md#getInstrumentBySymbols) | **GET** /instruments/?symbols&#x3D;{{symbols}} | 
[**getInstruments**](InstrumentServiceApi.md#getInstruments) | **GET** /instruments?{{params}} | 


<a name="getBarsData"></a>
# **getBarsData**
> Blotter getBarsData(params)



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.InstrumentServiceApi();

var params = "params_example"; // String | set of parameters to get chart data. ***NEEDS WORK***

apiInstance.getBarsData(params).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **params** | **String**| set of parameters to get chart data. ***NEEDS WORK*** | 

### Return type

[**Blotter**](Blotter.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getInstrumentByID"></a>
# **getInstrumentByID**
> Instrument getInstrumentByID(instrumentID)



Returns details on a specific instrument.

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.InstrumentServiceApi();

var instrumentID = "instrumentID_example"; // String | ID of Instrument to fetch

apiInstance.getInstrumentByID(instrumentID).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **instrumentID** | **String**| ID of Instrument to fetch | 

### Return type

[**Instrument**](Instrument.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getInstrumentBySymbols"></a>
# **getInstrumentBySymbols**
> Instruments getInstrumentBySymbols(symbols)



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.InstrumentServiceApi();

var symbols = "symbols_example"; // String | Array of symbols of Instrument to fetch

apiInstance.getInstrumentBySymbols(symbols).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **symbols** | **String**| Array of symbols of Instrument to fetch | 

### Return type

[**Instruments**](Instruments.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getInstruments"></a>
# **getInstruments**
> Instruments getInstruments(params)



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.InstrumentServiceApi();

var params = "params_example"; // String | ID of user to fetch

apiInstance.getInstruments(params).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **params** | **String**| ID of user to fetch | 

### Return type

[**Instruments**](Instruments.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

