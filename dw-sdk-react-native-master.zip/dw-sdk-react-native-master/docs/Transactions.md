# DrivewealthSdk.Transactions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderID** | **String** |  | [optional] 
**orderNo** | **String** |  | [optional] 
**symbol** | **String** |  | [optional] 
**cumQty** | **String** |  | [optional] 
**orderStatus** | **String** |  | [optional] 
**orderType** | **String** |  | [optional] 
**orderQty** | **String** |  | [optional] 
**orderCashAmt** | **String** |  | [optional] 
**createdWhen** | **String** |  | [optional] 
**updatedReason** | **String** |  | [optional] 
**side** | **String** |  | [optional] 
**commission** | **String** |  | [optional] 
**executedWhen** | **String** |  | [optional] 
**stopPrice** | **String** |  | [optional] 


