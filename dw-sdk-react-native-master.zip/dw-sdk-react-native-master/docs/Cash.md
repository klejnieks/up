# DrivewealthSdk.Cash

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cashAvailableForTrade** | **String** |  | [optional] 
**cashAvailableForWithdrawal** | **String** |  | [optional] 
**cashBalance** | **String** |  | [optional] 


