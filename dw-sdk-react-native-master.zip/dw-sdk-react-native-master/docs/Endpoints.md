# DrivewealthSdk.Endpoints

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


