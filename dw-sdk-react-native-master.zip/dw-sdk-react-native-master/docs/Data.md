# DrivewealthSdk.Data

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**languageID** | **String** | Media&#39;s name | [optional] 
**wlpID** | **String** | username for forgot password | [optional] 
**utmSource** | **String** | username for forgot password | [optional] 
**utmCampaign** | **String** | username for forgot password | [optional] 
**utmContent** | **String** | username for forgot password | [optional] 
**utmMedium** | **String** | username for forgot password | [optional] 
**utmTerm** | **String** | username for forgot password | [optional] 
**referralCode** | **String** | username for forgot password | [optional] 


