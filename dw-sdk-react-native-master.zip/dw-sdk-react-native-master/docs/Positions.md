# DrivewealthSdk.Positions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**symbol** | **String** |  | [optional] 
**instrumentID** | **String** |  | [optional] 
**openQty** | **String** |  | [optional] 
**costBasis** | **String** |  | [optional] 
**marketValue** | **String** |  | [optional] 
**side** | **String** |  | [optional] 
**priorClose** | **String** |  | [optional] 
**availableForTradingQty** | **String** |  | [optional] 
**avgPrice** | **String** |  | [optional] 
**mktPrice** | **String** |  | [optional] 
**unrealizedPL** | **String** |  | [optional] 
**unrealizedDayPLPercent** | **String** |  | [optional] 
**unrealizedDayPL** | **String** |  | [optional] 


