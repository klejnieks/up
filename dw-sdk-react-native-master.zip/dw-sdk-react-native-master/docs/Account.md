# DrivewealthSdk.Account

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nickname** | **String** |  | [optional] 
**accountID** | **String** |  | [optional] 
**accountNo** | **String** |  | [optional] 
**accountType** | **String** |  | [optional] 
**createdWhen** | **String** |  | [optional] 
**currencyID** | **String** |  | [optional] 
**freeTradeBalance** | **Number** |  | [optional] 
**goodFaithViolations** | **Number** |  | [optional] 
**ibID** | **String** |  | [optional] 
**interestFree** | **Boolean** |  | [optional] 
**longOnly** | **Boolean** |  | [optional] 
**margin** | **Number** |  | [optional] 
**openedWhen** | **String** |  | [optional] 
**patternDayTrades** | **Number** |  | [optional] 
**status** | **Number** |  | [optional] 
**tradingType** | **String** |  | [optional] 
**commisionSchedule** | **Object** |  | [optional] 
**equityValue** | **Number** |  | [optional] 
**cash** | **Object** |  | [optional] 
**positions** | **Object** |  | [optional] 
**positionsAsSymbols** | **Object** |  | [optional] 
**positionsBySector** | **Object** |  | [optional] 
**orders** | **Object** |  | [optional] 
**lifetimePl** | **Number** |  | [optional] 
**lifetimePlPercent** | **Number** |  | [optional] 
**dailyPl** | **Number** |  | [optional] 
**dailyPlPercent** | **Number** |  | [optional] 
**hasPosition** | **Boolean** |  | [optional] 


