# DrivewealthSdk.AccountsServiceApi

All URIs are relative to *http://api.drivewealth.io/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAccountByID**](AccountsServiceApi.md#getAccountByID) | **GET** /users/{{userID}}/accounts/{{accountID}} | 
[**getAccounts**](AccountsServiceApi.md#getAccounts) | **GET** /users/{{userID}}/accounts | 
[**getSummary**](AccountsServiceApi.md#getSummary) | **GET** /users/{{userID}}/accountSummary/{{accountID}} | 


<a name="getAccountByID"></a>
# **getAccountByID**
> User getAccountByID(userID, accountID)



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.AccountsServiceApi();

var userID = "userID_example"; // String | ID of user to fetch

var accountID = "accountID_example"; // String | ID of user to fetch

apiInstance.getAccountByID(userID, accountID).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userID** | **String**| ID of user to fetch | 
 **accountID** | **String**| ID of user to fetch | 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getAccounts"></a>
# **getAccounts**
> User getAccounts(userID)



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.AccountsServiceApi();

var userID = "userID_example"; // String | ID of user to fetch

apiInstance.getAccounts(userID).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userID** | **String**| ID of user to fetch | 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getSummary"></a>
# **getSummary**
> User getSummary(userID, accountID)



Returns the account blotter for a given user and account id

### Example
```javascript
var DrivewealthSdk = require('drivewealth-sdk');

var apiInstance = new DrivewealthSdk.AccountsServiceApi();

var userID = "userID_example"; // String | ID of user to fetch

var accountID = "accountID_example"; // String | ID of user to fetch

apiInstance.getSummary(userID, accountID).then(function(data) {
  console.log('API called successfully. Returned data: ' + data);
}, function(error) {
  console.error(error);
});

```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userID** | **String**| ID of user to fetch | 
 **accountID** | **String**| ID of user to fetch | 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

