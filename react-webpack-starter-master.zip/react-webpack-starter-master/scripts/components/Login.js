import React, {Component} from 'react';


class Login extends Component {

    constructor(props) {
        super(props);

        this.state = {
            username: "",
            password: ""
        };
    }

    onUsernameChange(event) {
        this.setState({username: event.target.value});
    }

    onPasswordChange(event) {
        this.setState({password: event.target.value});
    }

    onSubmit(event) {
        var data = {
            username: this.state.username,
            password: this.state.password,
            ipAddress: '1.1.1.1',
            languageID: 'en_US',
            srcRes: screen.availWidth + 'x' + screen.availHeight
        };

        this.login(data)
        .then(response => {
            debugger;
        })
        .catch((error) => {
            debugger;
        });
    }


    /////////////
    login(data):Promise {
        if(!data || typeof data === 'undefined') reject(new Error("You must supply a login data object"));

        return new Promise((resolve, reject) => {
            fetch('https://api.drivewealth.io/v1' + '/userSessions/', {
    			method: 'POST',
    			headers: {
    				'Accept': 'application/json',
    				'Content-Type': 'application/json'
    			},
    			body: JSON.stringify({
    				"appTypeID": '2000',
    				"appVersion": '0.0.0.1',
    				"emailAddress": data.username,
    				"ipAddress": data.ipAddress || '0.0.0.0',
    				"languageID": data.languageID || 'en_US',
    				"osType": data.osType || 'web',
    				"osVersion": data.osVersion || "web",
    				"username": data.username,
    				"password": data.password,
    				"scrRes": data.srcRes || '0x0'
    			})
    		})
            .then((response) => {
                if(response.ok) {
                    response.json().then(json => {
                        debugger;
                        resolve(json)
                    });
                }
                else {
                    response.text().then(text => reject(text));
                }
            })
            .catch((err) => {
                debugger;
                reject(err)
            });
        });
    }
    ///////////

    render() {
        return (
            <div>
                <h1>Login</h1>

                <input type="text" value={this.state.value} onChange={::this.onUsernameChange} />
                <input type="text" value={this.state.value} onChange={::this.onPasswordChange} />

                <button onClick={::this.onSubmit}>Reset</button>
            </div>
        )
    }
}

export default Login;
