import React, {Component} from 'react';
import PureRenderMixin from 'react-addons-pure-render-mixin';
import Header from './Header';
import TableRow from './TableRow';

class About extends Component {

    static defaultProps = {
        username: "thats not my name",
        contentProp: "Content from props..."
    }

    constructor(props) {
        super(props);

        this.shouldComponentUpdate = ::PureRenderMixin.shouldComponentUpdate;

        this.state = {
            color: "#006699",
            data: [{
                "id":1,
                "name":"Foo",
                "age":"20"
            },{
                "id":2,
                "name":"Bar",
                "age":"30"
            },{
                "id":3,
                "name":"Baz",
                "age":"40"
            }]
        }
    }

    changeColor() {
        this.setState({
            color: "#000000"
        });
    }

    addListItem() {
        var n = this.state.data.length;
        var data = this.state.data;
        data.push({"id": n, "name": "item-" + n, "age": 36});

        this.setState({
            data: data
        })
    }

    render() {



        return (
            <div>
                <Header />

                <table>
                    <tbody>
                        {this.state.data.map((person, i) => <TableRow key = {i} data = {person} />)}
                    </tbody>
                </table>

                <h2 className="myStyle">Hello <i>{this.props.username}</i>.</h2>
                <p data-myName="klejnieks">This is FPO, this is some content {this.props.contentProp}</p>
                <p>Trivial Math 1 + 1 = {1+1}</p>

                <br/>
                <p style={{'backgroundColor': this.state.color, 'color': '#FFF', 'padding': 10}}>Color is set to: {this.state.color}</p>

                <button onClick={::this.changeColor} className="button success">Change Color</button>
                <button onClick={::this.addListItem} className="button success">Add Item to List</button>

            </div>
        );
    }
}

export default About;
