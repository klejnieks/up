import React, {Component} from 'react';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';

import Login from './components/Login';

class Contact extends Component {
    render() {
        return (
            <div>
                <h1>Contact...</h1>
                <ReactCSSTransitionGroup transitionName="example"
                    transitionAppear={true}
                    transitionAppearTimeout={500}
                    transitionEnter={false}
                    transitionLeave={false}>
                    <h1>My Element...</h1>
                </ReactCSSTransitionGroup>
                <Login />
            </div>
        )
    }
}

export default Contact;
