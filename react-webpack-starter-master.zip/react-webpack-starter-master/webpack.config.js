var webpack = require('webpack'),
    path = require('path'),
    ExtractTextPlugin = require("extract-text-webpack-plugin"),
    loaders = require('./webpack.loaders');

var config = {
    entry: './scripts/main.js',
    output: {
        path: './',
        filename: 'index.js',
    },
    devServer: {
        hot: true,
        inline: true,
        port: 8686,
    },
    resolve: {
        extensions: ['', '.js', '.jsx'],
        modulesDirectories: ['node_modules', 'components']
    },
    module: {
        loaders: loaders
    },
    postcss: [
        require('autoprefixer-core'),
        require('postcss-color-rebeccapurple')
    ],
    plugins: [
        new ExtractTextPlugin("style.css", { allChunks: true }),
    ]
};

module.exports = config;
