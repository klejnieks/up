# react-webpack-starter
This is a very trivial starter project to get up and running with recatjs and webpack
